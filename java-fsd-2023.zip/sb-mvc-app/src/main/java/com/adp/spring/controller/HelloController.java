package com.adp.spring.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
	
	@Value("${application.message:Hello World}")
	private String helloMessage;
	
	// http://localhost:8082/hello
//	@RequestMapping(value = "/hello",method = RequestMethod.GET )
	@GetMapping("/hello")
	public String sayHello(Model model) {
		model.addAttribute("message", helloMessage);
		return "hello";
	}
}