package com.adp.app;


/**
 *  Javadoc-style  comment
 * @author Srini
 * This is a sample application to showcase typecasting
 *
 *  javadoc *.java
 */
public class TypecastDemo {

	public static void main(String[] args) {
		//Widening : lowertype=>highertype, implicit
		int radius=5;
		//		double areaOfCircle;

		/* This is a mulit-line comment
		 * Computing area of the circle.
		 * 
		 */
		double areaOfCircle =  Math.PI * radius * radius;

		System.out.println("Area of circle: " + areaOfCircle);

		System.out.println("Addition: " + (5 + 6));
		System.out.println(5+6);

		//Narrowing : highertype=>lowertype, explicit
		int x = (int) 3.5;
		System.out.println(x);

		float price = 34560.50f;
		boolean flag=true;
		//		int y=flag;

		int value=0;
		//		flag=value;

		//		char ch=null;
		Character cha = null;

		//getAreaOfRectangle() is a static/class method
		double areaRect = getAreaOfRectangle(3.7,6.4); //actual parameters

		System.out.println("Area of rectangle is : "+ areaRect);

		/*
		 * long getPower(int base, int exponent) return base to the power of exponent
		 * Note: Not to use Math.pow()
		 */
		int b=2;
		int e=3;
		long areaPow  = getPower(b,e);
		System.out.println(areaPow);

		/*
		 * void showTimings(String showType);
		 * Use switch statement
		 * 
		 * showTimings("first");
		 * valid values: morning, matinee, first, second
		 */


		String showType= "first";
		showTimings(showType);

		/*
		 * LocalDate, LocalTime, LocalDateTime classes are in package, java.time
		 * 
		 * The above classes have a static method, now() that returns object of respective types
		 * 
		 * Explore the instance methods of the above classes.
		 * 
		 * 
		 * Note: Date, GregorianCalendar are legacy classes that belong to java.util package
		 * 
		 *   
		 */
		
		
	}

	private static void showTimings(String showType) {
		switch(showType) {
		case "morning" : System.out.println("Show begins at 9 AM");
						break;
		case "matinee": System.out.println("Show begins at 2 PM");
						break;
		case "first": System.out.println("Show begins at 6 PM");
						break;
		case "second" : System.out.println("Show begins at 9 PM");
						break;
		default: System.out.println("Invalis show type");
						break;



		}

	}

	private static long getPower(int b, int e) {
		long result=1;
		for(int i=1; i<=e;i++ ) {
			result= result * b;
		}
		return result;
	}

	//d and e are called formal paraemeters
	/**
	 * 
	 * @param d : width of a rectangle
	 * @param e  : length of a rectangle
	 * @return   : area of the rectangle
	 */
	private static double getAreaOfRectangle(double d, double e) {
		return d*e;
	}

}
