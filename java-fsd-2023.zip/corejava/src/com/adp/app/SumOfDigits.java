package com.adp.app;
/**
 * 
 * @author sriniva1
 *
 */
public class SumOfDigits {

	public static void main(String[] args) {
		/*
		 * main() receives 2 integer values. Display its sum and average
		 * 
		 * Note: Use parseXXX() method of wrapper class to convert String object
		 * to int
		 */
//		try {
//			int x1= Integer.parseInt(args[0]);
//			int x2= Integer.parseInt(args[1]);
//			System.out.println(x1+x2);
//			double sum = (x1+x2)/2.0;
//			System.out.println("Sum = "+ sum);
//			
//		}catch(NumberFormatException e) {
//			e.printStackTrace();
//		}catch(ArrayIndexOutOfBoundsException e) {
//			e.printStackTrace();
//		}
//		
		
		
		/*
		 * double getAverageOfNumbers(int values[]) receives array of integer values and returns
		 * its average.
		 * 
		 * Note: The main() receives numbers as command-line arguments
		 */
		
		int list[] = new int[args.length];
		try {
			for(int i=0;i<args.length;i++) {
				list[i] = Integer.parseInt(args[i]);
			}
			
			double result = getAverageOfNumbers(list);
			System.out.println(result);
			
		}catch(NumberFormatException e) {
			e.printStackTrace();
		}
		
		
		/* Single-dimensional arrays
		 * syntax:
		 * 		datatype arrayName[] = new datatype[NE];
		 * 		where NE is number of elements
		 * 
		 * 		Note: datatype can be primitive type or reference type
		 * 	
		 * 		Ex.  int list[] = new int[100];
		 * 
		 * 		Ex.  String words[] = new String[5];
		 * 
		 * 
		 */
		
		
		
		
		System.out.println("END");

	}

	private static double getAverageOfNumbers(int[] list) {
		int sum=0;
		//for each loop
		for(int i : list) {
			sum += i;
		}
		return (double)sum/list.length;
	}

}
