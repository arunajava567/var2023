package com.adp.app;

import com.adp.service.Circle;

public class CircleDemo {

	public static void main(String[] args) {
		// ClassName objectName= new ClassName([<args>])
		
//		Circle circle1= new Circle();
//		Circle circle2= new Circle(5);
//		System.out.println("Radius of circle1= "+ circle1.getRadius());
//		System.out.println("Radius of circle2= "+ circle2.getRadius());
//		
//		circle1.setRadius(10);
//		System.out.println("Radius of circle2= "+ circle1.getRadius());
//		
//		System.out.println("Area of circle1= "+ circle1.getArea());
//		System.out.println("Circumference of circle2= "+ circle1.getCircumference());
		
		Circle circle1= new Circle(5);
		Circle circle2 = new Circle(5);
//		Circle circle3= circle1;
//		circle2=null;
		
		System.out.println(circle1.equals(circle2));
		System.out.println(circle1.hashCode());
		System.out.println(circle2.hashCode());
		
		/* By default returns packageName.className@hexadecimal representation of 
		 * object's hashcode.
		 * 	com.adp.service.Circle@24
		 *  com.adp.service.Circle@24
		 * For an object of user-defined class to return state of an object, override
		 * toString() method
		 * 
		 */

		System.out.println(circle1);
		System.out.println(circle2);
		

	}

}
