package com.adp.app;

import com.adp.util.MyMath;

/**
 * 
 * @author sriniva1
 *  This class tests the static methods of MyMath class
 */
public class MyMathTester {

	public static void main(String[] args) {
		System.out.println("Factorial of 5 =" + MyMath.factorial(5) ) ;
		
	}

}
