package com.adp.app;

public class WrapperDemo {

	public static void main(String[] args) {
		//int ->Integer, called as auto-boxing
		Integer size = 50;
		//Integer->int, called auot-unboxing
		int newSize = size;
		System.out.println(size+","+newSize);

		Double d = 10.0;
	}

}
