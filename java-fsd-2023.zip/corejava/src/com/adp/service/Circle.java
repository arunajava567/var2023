package com.adp.service;

import java.util.Objects;
/**
 * 
 * @author sriniva1
 *  Objects of user-defined classes even though have same state return different
 *  hashCode and equals() returns false.
 *  
 *  To return same hashcode  if state is same, override equals() and hashCode() methods,
 *  then equals() returns true
 *  
 *  
 */
public class Circle {
	private int radius;
	
	//default constructor
	public Circle() {
		
	}
	
	//1-arg constructor
	public Circle(int radius) {
		this.radius=radius;
	}
	
	
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public double getArea() {
		return Math.PI* this.radius * this.radius;
	}
	
	public double getCircumference() {
		return 2* Math.PI * this.radius;
	}

	@Override
	public int hashCode() {
		return Objects.hash(radius);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Circle other = (Circle) obj;
		return radius == other.radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}
	
	
	
	
	
}
