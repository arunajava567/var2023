package com.adp.pms.app;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.adp.pms.dao.OracleConnection;
import com.adp.pms.dao.PersonDAO;

@SpringBootApplication(scanBasePackages = "com.adp.pms")
public class SbMvcPmsApplication implements CommandLineRunner{
	

	public static void main(String[] args) {
		SpringApplication.run(SbMvcPmsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		OracleConnection.testConnection();
		
	}

}
