package com.adp.pms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.adp.pms.service.PersonService;

@Controller
public class PersonController {
	@Autowired
	private PersonService personService;
	
	
}
