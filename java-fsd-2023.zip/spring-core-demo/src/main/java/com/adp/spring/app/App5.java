package com.adp.spring.app;


import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.adp.spring.model.Country;


public class App5 {
    public static void main(String[] args) {
        ApplicationContext context=null;
        try {
            //IoC container
            context= new ClassPathXmlApplicationContext("inject-collection.xml");

            Country country= (Country) context.getBean("countryBean");
            System.out.println("Country List.....");
            country.getCountryList().stream().forEach(System.out::println);
            System.out.println("Country Set...");
            country.getCountrySet().stream().forEach(System.out::println);
            System.out.println("Country Map...");
            Map<String,String> countryMap= country.getCountryMap();
            for(Map.Entry<String,String> c: countryMap.entrySet()){
                System.out.println(c.getKey()+":"+c.getValue());
            }


            //shutdown IoC
            ((AbstractApplicationContext)context).registerShutdownHook();
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            ((AbstractApplicationContext)context).close();
        }
    }
}
