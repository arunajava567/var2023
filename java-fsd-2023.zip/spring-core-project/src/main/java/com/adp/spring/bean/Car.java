package com.adp.spring.bean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//Aggregation
//Car is also called Container class or Whole-of class
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Car {
	private String manufacturer;
	private String brandName;
	private Engine engine;
	
	
	
	
	
}
