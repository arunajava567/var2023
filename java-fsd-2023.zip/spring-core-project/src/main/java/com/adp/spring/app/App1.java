package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.adp.spring.bean.Person;



public class App1 {

	public static void main(String[] args) {
		ApplicationContext context=null;
	       try {
	    	   //IoC container
	    	   context = new ClassPathXmlApplicationContext("auto-wire.xml");
	    	  
	    	   Person person= (Person)context.getBean("personBean");
	    	   System.out.println(person);
	    	   
	    	   //shutdown IoC container
	    	   ((AbstractApplicationContext)context).registerShutdownHook();
	    	   
	       }catch(Exception e) {
	    	   e.printStackTrace();
	       }

	}

}
