package com.adp.spring.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.adp.spring.bean.Car;
import com.adp.spring.bean.Engine;

@Configuration
@PropertySource(value = "car.properties", ignoreResourceNotFound = true)
public class CarConfiguration {

	@Value("#{T(Long).parseLong('${Engine.Sno}')}")
	private Long sno;
	@Value("${Engine.Type}")
	private String engineTyp;
	@Value("#{T(Double).parseDouble('${Engine.Capacity}')}")
	private Double capacity;
	
	@Value("${Car.Manufacturer}")
	private String manufacturer;
	@Value("${Car.Brand}")
	private String brand;
	
	
	@Bean(value = "engineBean")
	public Engine getEngine() {
		return new Engine(sno,engineTyp,capacity);
	}
	
	@Bean(value = "carBean")
	public Car getCar() {
		return new Car(manufacturer,brand,getEngine());
	}
	
	
}
