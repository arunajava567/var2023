package com.adp.spring.bean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// called as contained class or part-of class
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Engine {
	private Long serialNumber;
	private String engineType;
	private Double capacity;
	
	
	
	
}
