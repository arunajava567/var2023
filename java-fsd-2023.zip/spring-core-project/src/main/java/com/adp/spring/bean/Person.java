package com.adp.spring.bean;

import java.time.LocalDate;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Person {
	private Long adharCard;
	private String name;
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate birthdate;
	
	/*
	 * @Autowired is by default, byType. We can disable this default behaviour
	 * and convert to byName using the following syntax
	 */
	@Autowired(required = false)
	@Qualifier(value = "personBean1")
	private Address permanentAddress;
	
	/*
	 * Spring annotations, @Autowired and @Qualifier can be replaced
	 * with javax annotation @Resource
	 */
//	@Autowired(required = false)
//	@Qualifier(value = "personBean2")
	@Resource(name = "personBean2")
	private Address temporaryAddress;


	//custom method that receives date as String and converts to LocalDate
	//conversion method converting String to LocalDate
	/*
			if setCustomDate() is a setter method, its property name will be customDate
	 */
	public void setCustomDate(String bdate) {
		if(!(bdate.isEmpty() && bdate.isBlank())){
			this.birthdate= LocalDate.parse(bdate);
		}
	}


}
