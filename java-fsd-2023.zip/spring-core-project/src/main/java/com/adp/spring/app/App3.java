package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.adp.spring.bean.Car;
import com.adp.spring.config.CarConfiguration;

public class App3 {

	public static void main(String[] args) {
		ApplicationContext context=null;
		try {
			context = new AnnotationConfigApplicationContext(CarConfiguration.class);
			Car car= (Car) context.getBean("carBean");
			System.out.println(car);

			//shutdown IoC 
			((AbstractApplicationContext)context).registerShutdownHook();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			((AbstractApplicationContext)context).close();
		}


	}

}
