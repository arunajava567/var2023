package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.adp.spring.bean.Address;
import com.adp.spring.bean.Person;

public class App {
    public static void main( String[] args ){
       ApplicationContext context=null;
       try {
    	   //IoC container
    	   context = new ClassPathXmlApplicationContext("spring.xml");
    	   /*
    	    * The default bean scope is singleton. so address1 and address1_c
    	    * are two references pointing to single Address object/bean.
    	    * 
    	    * If bean scope is set to prototype, then new bean is created when
    	    * getBean() is called.
    	    */
    	   Address address1 = (Address) context.getBean("addressBean");
    	   System.out.println(address1);
    	   
    	   Address address1_c = (Address) context.getBean("addressBean");
    	   System.out.println(address1_c);
    	   
    	   
    	   
    	   
    	   Address address2 = (Address) context.getBean("addressBean1");
    	   System.out.println(address2);
    	   
    	   Address address3 = (Address) context.getBean("addressBean2");
    	   System.out.println(address3);
    	   
    	   Person person = (Person) context.getBean("personBean");
    	   System.out.println(person);
    	   
    	   Address address4 = (Address) context.getBean("addressBean3");
    	   System.out.println(address4);
    	   
    	   //shutdown IoC container
    	   ((AbstractApplicationContext)context).registerShutdownHook();
    	   
       }catch(Exception e) {
    	   e.printStackTrace();
       }
    }
}
