package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.adp.spring.bean.Employee;

public class App2 {

	public static void main(String[] args) {
		ApplicationContext context=null;
		try {
			//IoC container
			context = new ClassPathXmlApplicationContext("bean-life-cycle.xml");

			Employee employee= (Employee)context.getBean("employeeBean");
			System.out.println(employee);

			//shutdown IoC container
			((AbstractApplicationContext)context).registerShutdownHook();

		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
