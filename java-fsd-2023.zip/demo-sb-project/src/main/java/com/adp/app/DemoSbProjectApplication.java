package com.adp.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.adp.model.Person;
import com.adp.service.PersonService;

@SpringBootApplication
public class DemoSbProjectApplication {
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoSbProjectApplication.class, args);
		
	}
	
	@Bean(value = "personBean")
	public Person getPerson() {
		return new Person(12345678912L,"Smith");
	}

}
