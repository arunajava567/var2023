package com.adp.dao;

import java.sql.SQLException;
import java.util.List;

import com.adp.dto.Person;

public interface PersonDAO {
	public abstract List<Person> getAllPersons() throws SQLException;
	public abstract Person getPersonById(Long adharCard) throws SQLException;
	public abstract Person addPerson(Person person) throws SQLException;
	public abstract Person updateMobile(Long adharCard, Long mobile) throws SQLException;
	public abstract Long deletePerson(Long adharCard) throws SQLException;
}
 