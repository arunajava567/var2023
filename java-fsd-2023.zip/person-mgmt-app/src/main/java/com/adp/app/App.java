package com.adp.app;

import java.util.List;

import org.apache.log4j.Logger;

import com.adp.dto.Person;
import com.adp.exception.PersonException;
import com.adp.service.PersonService;
import com.adp.service.PersonServiceImpl;

public class App {
	public static Logger logger= Logger.getLogger(App.class);
	
    public static void main( String[] args ){
//        OracleConnection.testConnection();
    	
    	PersonService service= new PersonServiceImpl();
    	
    	try {
    		List<Person> personList = service.getAllPersons();
    		personList.stream().forEach(System.out::println);
    		
    	}catch(PersonException e) {
    		logger.error(e);
    	}catch(Exception e) {
    		logger.error(e);
    	}
    	
    	System.out.println("------------------------------------");
    	
    	try {
    		Person person = service.getPersonById(123456789234L);
    		System.out.println(person);
    		
    	}catch(PersonException e) {
    		logger.error(e);
    	}catch(Exception e) {
    		logger.error(e);
    	}
    	
    	System.out.println("-----------------------------------");
    	try {
    		Person person = service.updateMobile(123456789234L,9999999999L);
    		System.out.println(person);
    		
    	}catch(PersonException e) {
    		logger.error(e);
    	}catch(Exception e) {
    		logger.error(e);
    	}
    	
    	
    	
    }
    
    
    
    
    
    
    
}
