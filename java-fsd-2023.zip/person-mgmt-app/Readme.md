		Logging Framework
		
		
Log4J is an open source logging framework for Java applications.

Log Levels: lowest severity to highest severity

	DEBUG  --   debug()
	INFO   --   info()
	WARN   --   warn()
	ERROR  --   error()
	FATAL  --   fatal()
	

Appenders: Where to append the events?
Types of appenders:
		ConsoleAppender : log messages are appended to console
		FileAppender	: log messages are appended to file
			a. RollingFileAppender: To backup the log files
			b. DailyRollingFileAppender:  To backup the log files in the specified frequency
		HTMLAppender:  log messages are stored in html format
		SMTPAppender: log messages are emailed.
		DatabaseAppender: log messages are stored in database.
		
The Logger objects have a parent logger by default called as root logger. i.e 
every logger object implicitly extends root logger.

Logger rootLogger = Logger.getRootLogger();

To create class-level loggers,

Logger logger= Logger.getLogger(ClassName);

---------------------------------------------------------

java.sql.Date to java.time.LocalDate

  	toLocalDate()
  
  
 java.time.LocalDate to java.sql.Date
 
 	java.sql.Date.valueOf(localDate object)
  





		