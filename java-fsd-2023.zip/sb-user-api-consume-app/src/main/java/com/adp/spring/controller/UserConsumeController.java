package com.adp.spring.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.adp.spring.bean.User;

@RestController
@RequestMapping("/ucc")
public class UserConsumeController {

	@Autowired
	private RestTemplate restTemplate;

	//http://localhost:8083/ucc/users/1
	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUserById(@PathVariable Integer id){
		String uri="http://localhost:8082/api/v1/users/{id}";
		try {
			Map<String, Integer> params = new HashMap<>();
			params.put("id", id);

			ResponseEntity<User> user = 
					restTemplate.getForEntity(uri, User.class, params);
			System.out.println(user);
			return user;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}



	}

	//http://localhost:8083/ucc/users
	@GetMapping("/users")
	public ResponseEntity<List<User>> getAllUsers(){
		String uri= "http://localhost:8082/api/v1/users";

		try {
			ResponseEntity<User[]> responseEntity = 
					restTemplate.getForEntity(uri, User[].class);
			List<User> userList = Arrays.asList(responseEntity.getBody());
			return new ResponseEntity<>(userList,HttpStatus.OK);

		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}


	//http://localhost:8083/ucc/users
	@PostMapping("/users")
	public ResponseEntity<User> addUser(@RequestBody User user) {
		String uri= "http://localhost:8082/api/v1/users";

		try {
			ResponseEntity<User> userResponseEntity= restTemplate.postForEntity(uri, user, User.class);

			return userResponseEntity;
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}

	}

	// http://localhost:8083/ucc/users
	@PutMapping("/users")
	public ResponseEntity<User> updateUser(@RequestBody User user){
		String uri= "http://localhost:8082/api/v1/update-user";
		try {
			restTemplate.put(uri, user);
			return ResponseEntity.ok().body(user);
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.CONFLICT,e.getMessage());
		}
	}

	// http://localhost:8083/ucc/users/1
	@DeleteMapping("/users/{id}")
	public ResponseEntity<Integer> deleteRestaurant(@PathVariable("id") Integer id){
		String uri="http://localhost:8082/api/v1/users/{id}";
		try {
			Map<String, Integer> params = new HashMap<>();
			params.put("id", id);
			restTemplate.delete(uri, params);
			return ResponseEntity.ok(id);
		}catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}



}
