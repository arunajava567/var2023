Exceptions are the errors that occur during execution of the 
application/program ie. at runtime.

When an exception occurs, JVM throws an exception object of appropriate exception type,
stops the execution at that statement where exception occurred and checks for appropriate 
exception handler. 
If found, exception object is trapped and then continues with normal execution of the program.
If not found, exception propogates outside the application resulting in abrupt termination 
which has to be avoided.

Exception handling:
	try{
		
	}catch(){
	
	}catch(){
	
	}
	
	====================================
	try{
		
	}catch(){
	
	}catch(){
	
	}finally{
	
	}
	=====================================
	try{
	
	}finally{
	
	}
	

The statements to be monitored by JVM at runtime for exceptions has to be kept
in try block.

When an exception object is thrown, control will check for appropriate catch block, if
found exception object is trapped in the catch block.

The statements in the finally block will always be executed whether exception occurs
or doesn't occur.


Built-in Exception hierarchy

					Object
					
					Throwable
	Error											Exception
	 OutOfMemoryError					RuntimeException		IOException
	 StackOverflowError				ArithmeticException
	 
	 
	 
 try with resource:
 	Resources are implicitly closed/released by the end of try block. So there
 	is no need of finally block.
 	
 	
 	
 	try(
 		allocate resources
 	){
 	
 	
 	
 	}catch(){
 	
 	}
		
		
	Custom Exception 
	
	a. Custom checked Exception:
	
		public class ClassName extends Exception {
	
		}	
		
	
	b. Custom unchecked Exception
		
		public class ClassName extends RuntimeException {
		
		
		}
				
				
	You need to explicitly throw custom exception objects
	
	   throw new CustomException();

	







