package com.adp.service;

import java.util.List;
import java.util.Map;

//Implement the methods using Stream API 
public class DuckService implements IDuck{

	@Override
	public List<String> getAllBreeds(List<Duck> duckList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Duck getDuckWithMaxWeight(List<Duck> duckList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void showDucksSortedByWeight(List<Duck> duckList) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, Integer> getBreedCount(List<Duck> duckList) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
