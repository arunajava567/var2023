package com.adp.suite;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@Suite
//@SelectPackages({"com.adp.model", "com.adp.util"})
@SelectClasses({com.adp.model.HelloWorldTest.class, 
						com.adp.model.HelloWorldNewTest.class})	
public class SuiteTest {
	
}
