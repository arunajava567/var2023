package com.adp.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/*
 * Tag annotation is an identifier of test class which
 * helps in filtering the test classes based on the tags.
 */
@Tag("MathTestTag")
class MyMathTest {

	@Test
	void testValidFactorial() {
		assertEquals(120, MyMath.factorial(5));
	}
	
	@Test
	@DisplayName("Checking for Invalid Factorial")
	void testInValidFactorial() {
		assertNotEquals(120, MyMath.factorial(4));
	}
	
	@ParameterizedTest
	@ValueSource(strings = {"calli","malli","keats","valli"})
	void testStringEndingWithi(String string) {
		assertTrue(string.endsWith("i"));
	}
	
	@ParameterizedTest
	@ValueSource(ints = {1,2,3,4,5})
	void testValidFactorial(Integer n) {
		assertNotEquals(120, MyMath.factorial(n));
	}
	
	@RepeatedTest(value=5)
	void testFactorialRepeated(Integer n) {
		assertEquals(120, MyMath.factorial(n));
	}
	
	
	@RepeatedTest(value = 5)
    @DisplayName("Repeating test")
    void customDisplayName(RepetitionInfo repInfo, TestInfo testInfo){
        int i=3;
//        assertEquals("repetition 1 of 5",testInfo.getDisplayName());
        assertNotEquals(repInfo.getCurrentRepetition(),i);

    }
	

}
