package com.adp.model;

/**
 * import static imports all the static members of the class.
 * So we can directly call the static methods without
 * applying ClassName.staticMethod(), direct call
 * staticMethod()
 */
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class HelloWorldTest {
	private HelloWorld helloWorld=null;

	
	/*
	 * This method executes before execution of each test method
	 */
	@BeforeEach
	void beforeEachTestMethod() {
		helloWorld = new HelloWorld("Welcome to JUnit5");
	}
	
	
	@AfterEach
	void afterEachTestMethod() {
		helloWorld=null;
	}
	
	@Disabled
	@Test
	void testGetterForValidData() {
		assertEquals("Welcome to JUnit5", helloWorld.getMessage());
	}
	
	@Disabled
	@Test
	void testGetterForInvalidData() {
		assertNotEquals("Welcome to JUnit5!!", helloWorld.getMessage());
	}
	
	@Test
	void testSetterForValidData() {
		helloWorld.setMessage("ThanQ");
		assertEquals("ThanQ", helloWorld.getMessage());
	}
	
	
	@Test
	void testSetterForInValidData() {
		helloWorld.setMessage("ThanQ");
		assertNotEquals("Welcome to JUnit5", helloWorld.getMessage());
	}
	
	@Test
	void testDefaultConstructor() {
		helloWorld = new HelloWorld();
		assertNull(helloWorld.getMessage());
		
	}
	
	@Test
	void testOneArgConstructor() {
		helloWorld= new HelloWorld("Hello World");
		assertNotNull(helloWorld);
	}
	
	
}
