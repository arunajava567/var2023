package com.adp.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class HelloWorldNewTest {
private HelloWorld helloWorld=null;

	@Disabled
	@BeforeAll
	static void beforeAll() {
		System.out.println("This code executes before all test methods");
	}
	
	@Disabled
	@AfterAll
	static void afterAll() {
		System.out.println("This code executes after all test methods");
	}
	
	/*
	 * This method executes before execution of each test method
	 */
	@BeforeEach
	void beforeEachTestMethod() {
		helloWorld = new HelloWorld("Welcome to JUnit5");
	}
	
	@AfterEach
	void afterEachTestMethod() {
		helloWorld=null;
	}
	
	@Test
	void testGetterForValidData() {
		assertEquals("Welcome to JUnit5", helloWorld.getMessage());
	}
	
	
	@Test
	void testGetterForInvalidData() {
		assertNotEquals("Welcome to JUnit5!!", helloWorld.getMessage());
	}
}
