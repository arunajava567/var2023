package com.adp.spring.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.adp.spring")
public class SbMvcThymeleafAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbMvcThymeleafAppApplication.class, args);
	}

}
