package com.adp.spring.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/gc")
public class GreetingController {

	// http://localhost:8082/gc/greeting?name=Srini
	//GetMapping is same as @RequestMapping + Http Method GET
	@GetMapping("/greeting")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	
	
	
	
	
	
	// http://localhost:8082/gc/greet?fname=Ravi&lname=Kumar
	// http://localhost:8082/gc/greet?fname=Ravi
	@GetMapping("/greet")
	public String greet(
			@RequestParam(name="fname", required=true) String firstName, 
			@RequestParam(name="lname", required=false) String lastName, 
			Model model) {
		model.addAttribute("fname", firstName);
		if(lastName != null) {
			model.addAttribute("lname", lastName);
		}else {
			model.addAttribute("lname", "");
		}
		return "greet";
	}
	
	
	
	@GetMapping("/employees/{id}")
	//wraps response into JSON object and renders to the browser
	@ResponseBody
	public String getEmployeesById(@PathVariable String id) {
	    return "ID: " + id;
	}
	
	
	
	// Foll. if path variable name and method parameter name are different
	@GetMapping("/emps/{id}")
	@ResponseBody
	public String getEmployeesByIdWithVariableName(@PathVariable("id") String employeeId) {
	    return "ID: " + employeeId;
	}
	

	
	@GetMapping("/employees/{id}/{name}")
	@ResponseBody
	public String getEmployeesByIdAndName(@PathVariable String id, 
												@PathVariable String name) {
	    return "ID: " + id + ", name: " + name;
	}
	
	
	
	@GetMapping("/emps/{id}/{name}")
	@ResponseBody
	public String getEmployeesByIdAndNameWithMapVariable(@PathVariable Map<String, String> pathVarsMap) {
	    String id = pathVarsMap.get("id");
	    String name = pathVarsMap.get("name");
	    if (id != null && name != null) {
	        return "ID: " + id + ", name: " + name;
	    } else {
	        return "Missing Parameters";
	    }
	}

}