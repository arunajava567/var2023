						Java Multithreading
						
	Concurrency
		Concurrency is a process where several applications or multiple parts of an
		application run simultaneously.
		
		Concurrent execution of multiple applications is multitasking.
		Ex. Windows OS is a multitask operating system.
		
		Concurrent execution of multiple parts of a single application is
		called multithreading.
		
		Ex. A streaming audio/video applications, Gaming applications etc
			are multithreaded application.
		
		An application is also called as process or a task.
		Ex. JVM is a process/task/application.
		
		Threads exist within a process. A process has atleast one thread.
		
		Ex. In JVM application, there are many threads, Ex. GC is one such thread.
		
		All the threads within a process share same data area but run different 
		sections of code.i.e each thread has a seperate path of execution running through
		code section.
		
		Multithreaded application in Java
		
		Method1. 
				Create a class that extends Thread
				
		Method2:
				Create a class that implements Runnable interface
				
				
		
		