package com.adp.app;

import com.adp.service.SharedRunnable;

public class SharedRunnableDemo {

	public static void main(String[] args) {
		//Runnable object
		SharedRunnable sharedRunnable= new SharedRunnable();
		
		Thread t1= new Thread(sharedRunnable);
		Thread t2= new Thread(sharedRunnable);
		
		t1.start();
		t2.start();
		

	}

}
