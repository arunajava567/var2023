package com.adp.service;

public class SharedRunnable implements Runnable {

	private static StringBuffer sb= new StringBuffer("Welcome");

	//unsynchronized method
	//	@Override
	//	public void run() {
	//		int size= sb.length();
	//		for(int i=0;i<size;i++) {
	//			System.out.println(Thread.currentThread().getName()+"---"+ sb.append("X"));
	//		}
	//		
	//	}

	//synchronized method
	//	@Override
	//	public synchronized void run() {
	//		int size= sb.length();
	//		for(int i=0;i<size;i++) {
	//			System.out.println(Thread.currentThread().getName()+"---"+ sb.append("X"));
	//		}
	//		
	//	}



	//synchronized block
	@Override
	public void run() {
		int size= sb.length();
		synchronized(this) {
			for(int i=0;i<size;i++) {
				System.out.println(Thread.currentThread().getName()+"---"+ sb.append("X"));
			}
		}

	}






}
