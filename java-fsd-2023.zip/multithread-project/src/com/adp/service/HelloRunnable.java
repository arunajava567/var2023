package com.adp.service;

import java.util.ArrayList;
import java.util.List;

public class HelloRunnable implements Runnable {
	
	List<Integer> empidList= new ArrayList<>();
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		
		long start= System.currentTimeMillis();
		
		for(int i=0; i<1000000;i++) {
			empidList.add(i);
		}
		
		System.out.println(empidList.stream().reduce((a,b)->a+b).get());
		
		long end = System.currentTimeMillis();
		
		System.out.println("Time taken: "+ (end-start)+" ms");
	}

}
