Manual Endpoints Test using Swagger

Open a browser and access http://localhost:8087/swagger-ui/index.html
All endpoints with the lock sign are secured. 
In order to access them, you need a valid JWT access token.

Click POST /auth/authenticate and then, click Try it out button

Provide the user credentials username and password

{ "password": "user", "username": "user" }
Click Execute button. It should return something like

Code: 200
{ "accessToken": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9..." }
Note 1: You can use the admin credentials to access more secured endpoints

Note 2: The token will expire in 10 minutes

Copy the accessToken value (without the double quotes)

Click the Authorize button at the top of the page

In Value input field, paste the copied token

Click Authorize button and then, click Close button

To create an order, click POST /api/orders and then, click Try it out button

Provide the description of the order

{ "description": "Buy two iPhones" }
Click Execute button. It should return something like

Code: 200
{
  "id": "718c9f40-5c06-4571-bc3e-3f888c52eff2",
  "description": "Buy two iPhones",
  "user": { "username": "user" },
  "createdAt": "..."
}