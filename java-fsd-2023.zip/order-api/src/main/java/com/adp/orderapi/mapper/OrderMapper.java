package com.adp.orderapi.mapper;

import com.adp.orderapi.dto.CreateOrderRequest;
import com.adp.orderapi.dto.OrderDto;
import com.adp.orderapi.model.Order;


public interface OrderMapper {

    Order toOrder(CreateOrderRequest createOrderRequest);

    OrderDto toOrderDto(Order order);
}