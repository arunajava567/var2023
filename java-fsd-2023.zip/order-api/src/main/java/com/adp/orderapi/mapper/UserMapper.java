package com.adp.orderapi.mapper;


import com.adp.orderapi.dto.UserDto;
import com.adp.orderapi.model.User;

public interface UserMapper {

    UserDto toUserDto(User user);
}