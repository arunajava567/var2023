package com.adp.orderapi.dto;

public record AuthResponse(String accessToken) {
}
