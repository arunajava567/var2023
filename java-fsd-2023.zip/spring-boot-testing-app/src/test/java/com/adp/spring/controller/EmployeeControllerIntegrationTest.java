package com.adp.spring.controller;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.internal.verification.VerificationModeFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import com.adp.spring.SpringBootTestingAppApplication;
import com.adp.spring.entity.Employee;
import com.adp.spring.service.EmployeeService;





@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = SpringBootTestingAppApplication.class)
@AutoConfigureMockMvc 
public class EmployeeControllerIntegrationTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService service;
    
   
    
    @Test
    public void whenPostEmployee_thenCreateEmployee() throws Exception {
        Employee employee = new Employee("alex", LocalDate.of(2000, 10,10));
        given(service.save(Mockito.any())).willReturn(employee);

        mvc.perform(post("/api/employees")
        		.contentType(MediaType.APPLICATION_JSON)
        		.content(JsonUtil.toJson(employee)))
        		.andExpect(status().isCreated())
        		.andExpect(jsonPath("$.name", is("alex")));
        
        verify(service, VerificationModeFactory.times(1)).save(Mockito.any());
        
        reset(service);
    }

    @Test
    public void givenEmployees_whenGetEmployees_thenReturnJsonArray() throws Exception {
        Employee alex = new Employee("alex", LocalDate.of(2000, 10,10));
        Employee john = new Employee("john", LocalDate.of(2000, 10,10));
        Employee bob = new Employee("bob", LocalDate.of(2000, 10,10));

        List<Employee> allEmployees = Arrays.asList(alex, john, bob);

        given(service.getAllEmployees()).willReturn(allEmployees);

        mvc.perform(get("/api/employees").contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$", hasSize(3)))
        .andExpect(jsonPath("$[0].name", is(alex.getName())))
        .andExpect(jsonPath("$[1].name", is(john.getName())))
                .andExpect(jsonPath("$[2].name", is(bob.getName())));
        
        verify(service, VerificationModeFactory.times(1)).getAllEmployees();
        reset(service);
    }

}