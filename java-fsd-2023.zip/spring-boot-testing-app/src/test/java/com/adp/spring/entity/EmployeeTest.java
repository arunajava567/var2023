package com.adp.spring.entity;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EmployeeTest {
	private Employee employee;

	@BeforeEach
	void setUp() throws Exception {
		employee = new Employee(1L,"Smith",LocalDate.of(1995, 10,5));
	}
	

	@AfterEach
	void tearDown() throws Exception {
		employee = null;
	}

	@Test
	void testAllArgConstructor() {
		assertNotNull(employee);
	}
	
	
	@Test
	void testDefaultConstructor() {
		Employee employee = new Employee();
		assertNotNull(employee);
	}
	
	//test methods for all getter and setter methods

}
