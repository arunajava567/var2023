package com.adp.pms.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.adp.pms.entity.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.PersistenceException;
import jakarta.persistence.TypedQuery;

@Repository(value = "personDAO")
public class PersonDaoImpl implements PersonDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Person> getAllPersons() throws PersistenceException {
//		String jql = "select p from Person p ";
		//following is same as above
		String jql = "from Person";
		try {
			TypedQuery<Person> query = entityManager.createQuery(jql, Person.class);
			return query.getResultList();

		}catch(Exception e) {
			throw new PersistenceException(e.getMessage(),e);
		}
	}

	@Override
	public Person getPersonById(Long adharCard) throws PersistenceException {
		try {
			Person person = entityManager.find(Person.class, adharCard);
			return person;

		}catch(Exception e) {
			throw new PersistenceException(e.getMessage(),e);
		}
	}

	@Override
	public Person addPerson(Person person) throws PersistenceException {
		try {
//			entityManager.getTransaction().begin();
			person.setAdharCard(null);
			entityManager.persist(person);
			entityManager.flush();
//			entityManager.getTransaction().commit();
			return person;
		}catch(Exception e) {
//			entityManager.getTransaction().rollback();
			throw new PersistenceException(e.getMessage(),e);
		}
	}

	@Override
	public Person updatePerson(Person person) throws PersistenceException {
		try {
//			entityManager.getTransaction().begin();

			Person updatedPerson = entityManager.merge(person);
			entityManager.flush();
//			entityManager.getTransaction().commit();
			return updatedPerson;
		}catch(Exception e) {
//			entityManager.getTransaction().rollback();
			throw new PersistenceException(e.getMessage(),e);
		}
	}

	@Override
	public Long deletePerson(Long adharCard) throws PersistenceException {
		try {
			Person person = this.getPersonById(adharCard);
			if(person != null) {
//				entityManager.getTransaction().begin();

				entityManager.remove(person);
				entityManager.flush();
//				entityManager.getTransaction().commit(); 
				return adharCard;
			}else {
				throw new Exception("Invalid AdharCard Number");
			}
		}catch(Exception e) {
//			entityManager.getTransaction().rollback();
			throw new PersistenceException(e.getMessage(),e);
		}
	}

	@Override
	public Person getPersonByMobile(Long mobile) throws PersistenceException {
		try {
			// Named parameter
			String jql = "select p from Person p where p.mobile = :mob";
			TypedQuery<Person> typedQuery = entityManager.createQuery(jql,Person.class);
			typedQuery.setParameter("mob", mobile);
			Person person = typedQuery.getSingleResult();
			if(person != null) {
				return person;
			}else {
				throw new Exception("Invalid Mobile Number");
			}
			
		}catch(Exception e) {
			throw new PersistenceException(e.getMessage(),e);
		}
		
	}

	@Override
	public List<Person> getPersonByAddressAndBirthdate(String address, LocalDate birthdate)
			throws PersistenceException {
		try {
			//positional parameters
			String jql = "Select p from Person where p.address= ?1 and p.birthdate = ?2";
			TypedQuery<Person> typedQuery = entityManager.createQuery(jql,Person.class);
			typedQuery.setParameter(1, address);
			typedQuery.setParameter(2, birthdate);
			List<Person> personList =  typedQuery.getResultList();
			if(personList.size()==0) {
				throw new Exception("No persons");
			}
			return personList;
			
		}catch(Exception e) {
			throw new PersistenceException(e.getMessage(),e);
		}
	}

	
	



}
