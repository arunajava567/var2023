package com.adp.pms.dao;

import java.time.LocalDate;
import java.util.List;

import com.adp.pms.entity.Person;

import jakarta.persistence.PersistenceException;



public interface PersonDAO {
	public abstract List<Person> getAllPersons() throws PersistenceException;
	public abstract Person getPersonById(Long adharCard) throws PersistenceException;
	public abstract Person addPerson(Person person) throws PersistenceException;
	public abstract Person updatePerson(Person person) throws PersistenceException;
	public abstract Long deletePerson(Long adharCard) throws PersistenceException;
	public abstract Person getPersonByMobile(Long mobile) throws PersistenceException;
	public abstract List<Person> getPersonByAddressAndBirthdate(String address, LocalDate birthdate) throws PersistenceException;
}
 