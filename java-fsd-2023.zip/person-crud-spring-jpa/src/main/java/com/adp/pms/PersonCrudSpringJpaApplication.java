package com.adp.pms;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.adp.pms.entity.Person;
import com.adp.pms.exception.PersonException;
import com.adp.pms.service.PersonService;

//@SpringBootApplication
//public class PersonCrudSpringJpaApplication implements CommandLineRunner{
//
//	@Autowired
//	private PersonService personService;
//
//	public static void main(String[] args) {
//		SpringApplication.run(PersonCrudSpringJpaApplication.class, args);
//	}
//
//	@Override
//	public void run(String... args) throws Exception {
//
//		try {
//
//
//			//Create operation
////			Person person= new Person("Madhavi",LocalDate.of(2000, 10, 15),"Chennai",
////					8898675600L,"madhavi@gmail.com");
////			Person newPerson = personService.addPerson(person);
////			System.out.println(newPerson);
//
//			//Read operation
////			Person personRead = personService.getPersonById(6L);
////			if(personRead != null) {
////				System.out.println(personRead);
////			}else {
////				System.out.println("Invalid AdharCard Number");
////			}
//
//			//Read all operation
////			List<Person> personList = personService.getAllPersons();
////			personList.stream().forEach(System.out::println);
//
//
//			//Update operation
////			Person personToUpdate = personService.getPersonById(6L);
////			if(personToUpdate != null) {
////				
////				personToUpdate.setAddress("Hyderabad");
////				Person personUpdated = personService.updatePerson(personToUpdate);
////				System.out.println(personUpdated);
////			}else {
////				System.out.println("Invalid AdharCard Number");
////			}
//
//			
//			//Delete operation
////			Person personToDelete = personService.getPersonById(22L);
////			if(personToDelete != null) {
////				Long id = personService.deletePerson(22L);
////				System.out.println(id +": deleted");
////			}
//			
//			//find details of Person whose mobile number is 8898675600
//			Person person =  personService.getPersonByMobile(8898675601L);
//			System.out.println(person);
//			
//
//		}catch(PersonException e) {
//			e.printStackTrace();
//
//
//		}
//	}
//
//}




@SpringBootApplication
public class PersonCrudSpringJpaApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(PersonCrudSpringJpaApplication.class, args);
	}

	

}