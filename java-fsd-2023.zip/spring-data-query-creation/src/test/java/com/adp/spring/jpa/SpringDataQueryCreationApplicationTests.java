package com.adp.spring.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataQueryCreationApplicationTests {

	@Test
	void contextLoads() {
	}

}
