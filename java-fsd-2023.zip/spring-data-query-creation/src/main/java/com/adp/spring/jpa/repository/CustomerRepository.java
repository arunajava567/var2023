package com.adp.spring.jpa.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.adp.spring.jpa.entity.Customer;


@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	Optional<Customer> findByEmailId(String emailId);

	Optional<Customer> findByEmailIdAndName(String emailId, String name);

	List<Customer> findByEmailIdOrName(String emailId, String name);

	List<Customer> findByBirthdateBetween(LocalDate fromDate, LocalDate toDate);

	List<Customer> findByBirthdateLessThan(LocalDate dateOfBirth);

	List<Customer> findByBirthdateGreaterThan(LocalDate dateOfBirth);

	List<Customer> findByBirthdateAfter(LocalDate dateOfBirth);

	List<Customer> findByBirthdateBefore(LocalDate dateOfBirth);

	List<Customer> findByEmailIdNull();

	List<Customer> findByNameLike(String pattern);

	List<Customer> findByNameOrderByBirthdate(String name);

	List<Customer> findByNameOrderByBirthdateDesc(String name);
	
	
	
	@Query("SELECT c.name FROM Customer c WHERE c.emailId = :emailId")
	String findNameByEmailId(@Param("emailId") String emailId);

	@Query("UPDATE Customer c SET c.emailId = :emailId WHERE c.customerId = :customerId")
	@Modifying
	@Transactional
	Integer updateCustomerEmailId(@Param("emailId") String updateCustomerByEmailId, @Param("customerId") Integer customerId);

	@Query("DELETE FROM Customer c WHERE c.emailId = :emailId")
	@Modifying
	@Transactional
	Integer deleteCustomerByEmailId(@Param("emailId") String emailId);

}
