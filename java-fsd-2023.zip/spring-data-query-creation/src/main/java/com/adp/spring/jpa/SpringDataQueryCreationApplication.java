package com.adp.spring.jpa;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.adp.spring.jpa.dto.CustomerDTO;
import com.adp.spring.jpa.service.CustomerServiceImpl;
/*
 * 
 * insert the following sample data into the table

   1, 'martin@adp.com', 'martin', '08-AUG-1998'
   2, 'john@adp.com', 'john', '09-FEB-1999');
   3, 'raj@adp.com', 'raj', '09-DEC-1999');
   4, 'kiran@adp.com', 'kiran', '09-FEB-1989');
   5, 'ram@adp.com', 'ram', '09-FEB-1979');
 */
@SpringBootApplication
public class SpringDataQueryCreationApplication implements CommandLineRunner{

	@Autowired
	private CustomerServiceImpl customerService;
	
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringDataQueryCreationApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		findByEmailId();
		findByEmailIdAndName();
		findByEmailIdOrName();
//		findByDateOfBirthBetween();
//		findByDateOfBirthLessThan();
//		findByDateOfBirthGreaterThan();
//		findByDateOfBirthAfter();
//		findByDateOfBirthBefore();
//		findByEmailIdIsNull();
//		findByNameLike();
//		findByNameOrderByDateOfBirth();
//		findByNameOrderByDateOfBirthDesc();

		
		
//		findNameByEmailId();
//		updateCustomerByEmailId();
//		deleteCustomerByEmailId();

	}

	public void findByEmailId() {

		try {

			CustomerDTO customerDTO = customerService.findByEmailId("martin02@adp.com");
			System.out.println(customerDTO.getName());
		} catch (Exception e) {


		}

	}

	public void findByEmailIdAndName() {

		try {

			CustomerDTO customerDTO = customerService.findByEmailIdAndName("martin@adp.com", "martin");

			System.out.println(customerDTO);
		} catch (Exception e) {


		}

	}

	public void findByEmailIdOrName() {

		try {

			List<CustomerDTO> customerList = customerService.findByEmailIdOrName("martin@adp.com", "martin");

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}

	}

	public void findByDateOfBirthBetween() {
		try {
			LocalDate fromDate = LocalDate.of(1995, 1, 1);
			LocalDate toDate = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerList = customerService.findByBirthdateBetween(fromDate, toDate);

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByDateOfBirthLessThan() {
		try {

			LocalDate dateOfBirth = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerList = customerService.findByBirthdateLessThan(dateOfBirth);

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByDateOfBirthGreaterThan() {
		try {

			LocalDate dateOfBirth = LocalDate.of(1995, 12, 31);

			List<CustomerDTO> customerList = customerService.findByBirthdateGreaterThan(dateOfBirth);

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByDateOfBirthAfter() {
		try {

			LocalDate dateOfBirth = LocalDate.of(1995, 12, 31);

			List<CustomerDTO> customerList = customerService.findByBirthdateAfter(dateOfBirth);

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByDateOfBirthBefore() {
		try {

			LocalDate dateOfBirth = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerList = customerService.findByBirthdateBefore(dateOfBirth);

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByEmailIdIsNull() {
		try {

			List<CustomerDTO> customerList = customerService.findByEmailIdNull();

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByNameLike() {
		try {

			List<CustomerDTO> customerList = customerService.findByNameLike("j%");

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	public void findByNameOrderByDateOfBirth() {
		try {
			List<CustomerDTO> customerList = customerService.findByNameOrderByBirthdate("martin");

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}

	void findByNameOrderByDateOfBirthDesc() {
		try {
			List<CustomerDTO> customerList = customerService.findByNameOrderByBirthdateDesc("martin");

			customerList.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
		} catch (Exception e) {


		}
	}
	
	
	public void findNameByEmailId() {
		try {
			String name = customerService.findNameByEmailId("john@adp.com");

			System.out.println("Customer name : " + name);

		} catch (Exception e) {

			
		}
	}

	public void updateCustomerByEmailId() {

		try {
			customerService.updateCustomerEmailId("martin02@adp.com", 1);
			System.out.println("UPDATE_SUCCESS");
		} catch (Exception e) {

			
		}
	}

	public void deleteCustomerByEmailId() {

		try {
			customerService.deleteCustomerByEmailId("martin02@adp.com");
			System.out.println("DELETE_SUCCESS");

		} catch (Exception e) {

			
		}
	}


}
