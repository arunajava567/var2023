package com.ado.app;

import com.adp.servicenew.B;

public class AccessModfierDemo {
	public static void main(String args[]) {
		B bobj= new B();
		bobj.showData();
	}
}
