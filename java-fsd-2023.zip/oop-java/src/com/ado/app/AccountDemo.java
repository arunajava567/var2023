package com.ado.app;

import java.util.Scanner;

import com.adp.service.Account;
import com.adp.service.CurrentAccount;
import com.adp.service.FixedDepositAccount;
import com.adp.service.SavingsAccount;
import com.adp.service.Transaction;

public class AccountDemo {
	private static Scanner scanner= new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Enter number of accounts..");
		int size= Integer.parseInt(scanner.nextLine());
		Account accounts[] = new Account[size];
		
		populateAccounts(accounts);
		
		System.out.println("Enter account number..");
		long accountno= Long.parseLong(scanner.nextLine());
		transaction(accounts, accountno);
		
		//array of interface type
		//can hold only instances/objects of implementation classes of Transaction interface
		Transaction transactions[]= new Transaction[4];
		transactions[0] = new SavingsAccount();
		transactions[1] = new CurrentAccount();
		//Type mismatch: cannot convert from FixedDepositAccount to Transaction
//		transactions[2]= new FixedDepositAccount();
		

	}

	

	private static void transaction(Account[] accounts, long accountno) {
		// TODO Auto-generated method stub
		
	}



	/*
	 * populate the array with objects different Account types. Hard-code the data
	 */
	private static void populateAccounts(Account[] accounts) {
		// TODO Auto-generated method stub
		
	}

}
