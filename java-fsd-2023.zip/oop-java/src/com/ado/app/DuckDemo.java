package com.ado.app;

import com.adp.service.Duck;

public class DuckDemo {

	public static void main(String[] args) {
		Duck duck1= new Duck();
		Duck duck2= new Duck("Alabio","White",1.5);
		
		System.out.println("Total duck count= "+ Duck.getDuckCount());
		
		System.out.println(duck1.getBreed()+","+duck1.getColor()+","+duck1.getWeight());
		System.out.println(duck2.getBreed()+","+duck2.getColor()+","+duck2.getWeight());
		
		duck1.setBreed("Allier");
		duck1.setColor("Gray");
		duck1.setWeight(2.5);
		System.out.println(duck1.getBreed()+","+duck1.getColor()+","+duck1.getWeight());
		
		//without overriding toString() : com.adp.service.Duck@36aa7bc2
		//override toString() to provide String representation of the object
		System.out.println(duck1);

	}

}
