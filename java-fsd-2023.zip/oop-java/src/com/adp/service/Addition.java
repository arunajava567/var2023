package com.adp.service;


/**
 * 
 * @author sriniva1
 *
 * If instance method in a class is defined more than once, it is called as
 * method overloading.
 * 
 * Rules of method overloading:
 * The method parameters should differ either in,
 *  a. No. of parameters
 *  b. Type of parameters
 *  c. order of parameters
 *  
 *  Note: return type is not checked in  method overloading. i.e
 *  in method overloading, only method parameters are considered but not
 *  the return type.
 *
 */
public class Addition {
	
	public int  add(int a, int b) {
		return a+b;
	}
	
//	public float add(int a, int b) {
//		return a+b;
//	}
	
	
	public float add(int a, float b) {
		return a+b;
	}
	
	public float add(float a, int b) {
		return a+b;
	}
	
	
	public int add(int a, int b, int c) {
		return a+b+c;
	}
	
	
	
	
}
