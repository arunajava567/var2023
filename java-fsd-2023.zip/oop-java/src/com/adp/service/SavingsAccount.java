package com.adp.service;

public class SavingsAccount extends Account implements Transaction{
	private Double balance;
	public static final Double rateOfInterest;
	
	static {
		rateOfInterest=3.4;
	}
	
	public SavingsAccount() {
		
	}

	public SavingsAccount(Long accountNumber, String accountType, Customer accountHolder, Double balance) {
		super(accountNumber, accountType, accountHolder);
		this.balance = balance;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}
	

	public static Double getRateofinterest() {
		return rateOfInterest;
	}

	/*
	 * Minimum balance of Rs. 1000/- has to be maintained
	 */
	@Override
	public Double withdraw(Double amount) {
		if(this.balance>=amount) {
			this.balance = this.balance-amount;
			return this.balance;
		}else {
			System.out.println("Insufficient Funds");
			return this.balance;
		}
		
	}

	@Override
	public Double deposit(Double amount) {
		this.balance= this.balance+amount;
		return this.balance;
	}

	@Override
	public String toString() {
		return super.toString() +"SavingsAccount [balance=" + balance;
	}
	
	

}
