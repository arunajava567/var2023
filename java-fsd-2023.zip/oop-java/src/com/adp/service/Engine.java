package com.adp.service;

//contained/part-of class
public class Engine {
	private Long serialNumber;
	private String type;
	private Double capacity;
	
	
	public Engine() {
		super();
	}


	public Engine(Long serialNumber, String type, Double capacity) {
		super();
		this.serialNumber = serialNumber;
		this.type = type;
		this.capacity = capacity;
	}


	public Long getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(Long serialNumber) {
		this.serialNumber = serialNumber;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public Double getCapacity() {
		return capacity;
	}


	public void setCapacity(Double capacity) {
		this.capacity = capacity;
	}


	@Override
	public String toString() {
		return "Engine [serialNumber=" + serialNumber + ", type=" + type + ", capacity=" + capacity + "]";
	}
	
	
	
	
}
