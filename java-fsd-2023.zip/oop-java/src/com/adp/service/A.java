package com.adp.service;

/**
 * 
 * @author sriniva1
 * Access modifiers: public, default/package-private, protected & private
 * 
 * Access modifiers are applied to members of a class i.e to data members as well as to
 * methods of a class.
 * 
 * 
 * public : public members are visible within the class, within all the classes
 * of the same package and also visible to the classes of other packages. 
 * i.e public members of a class are visible across all the packages.
 * 
 * default/package-private: default members of a class are visible within the class and
 * within the classes of same package.
 * 
 * protected: protected members of a class are visible within the class, within the
 * classes of same package and visible within the sub class which is in another package.
 * 
 * Difference between default and protected members of a class:
 * 
 * If super class is in one package and sub class is in a different package,then
 * the default members of super class are not visible to the sub class methods.
 * 
 * If super class is in one package and sub class is in a different package,then
 * the protected members of super class are visible to the sub class methods.
 * 
 * private: private members of a class are visible only within the class.
 * 
 * high visibility -> low visibility
 * public->protected->default->private
 * 
 * 
 * Note: The access modifier of an outer class can be either public or default/package-private
 * 
 */
public class A {
	private int data=5; // package-private

	public A() {

	}

	public A(int data) {
		this.data= data;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	public void showData() {
		System.out.println(this.data);
	}
	
	public static void greetings() {
		System.out.println("Hello! Welcome to ADP from class A");
	}

}
