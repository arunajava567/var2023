package com.adp.service;

/**
 * 
 * @author sriniva1
 *  To avoid instantiation of Account class, declare it as abstract.
 *  We create type of Account(such as Savings /Current/FD) but not Account
 */
public abstract class Account {
	private Long accountNumber;
	private String accountType;
	private Customer accountHolder;
	
	
	public Account() {
		
	}


	public Account(Long accountNumber, String accountType, Customer accountHolder) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.accountHolder = accountHolder;
	}


	public Long getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public Customer getAccountHolder() {
		return accountHolder;
	}


	public void setAccountHolder(Customer accountHolder) {
		this.accountHolder = accountHolder;
	}


	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountType=" + accountType + ", accountHolder="
				+ accountHolder + "]";
	}
	
	
	
}
