package com.adp.service;

import java.time.LocalDate;

/**
 * 
 * @author sriniva1
 *
 * The constructor methods of sub class by default invoke by default constructor method of
 * the super class.
 * 
 * For proper initialization of super class data members, explicitly invoke super() method
 * with parameters in the sub class constructor methods.
 * 
 * super() method is always the first statement in the constructor methods.
 */
public class Student extends Person{
	private Integer className ;
	private String section;
	private Integer rollNumber;
	private String grade;
	
	
	public Student() {
		super();
	}


	public Student(Long adharCard, String name, LocalDate birthdate,
			Integer className, String section, Integer rollNumber, String grade) {
		
		super(adharCard,name,birthdate); // invoking all-arg constructor of super class, Person
		
		this.className = className;
		this.section = section;
		this.rollNumber = rollNumber;
		this.grade = grade;
	}


	public Integer getClassName() {
		return className;
	}


	public void setClassName(Integer className) {
		this.className = className;
	}


	public String getSection() {
		return section;
	}


	public void setSection(String section) {
		this.section = section;
	}


	public Integer getRollNumber() {
		return rollNumber;
	}


	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	@Override
	public String toString() {
		return  super.toString()+"\n"+"className=" + className + ", section=" + section + ", rollNumber=" + rollNumber + ", grade="
				+ grade;
	}


	@Override
	public void getDetails() {
		System.out.println("Im a student");
		super.getDetails();// super class, Person class getDetails() is executed
	}


	@Override
	public void dayToDayActivity() {
		System.out.println("Wakes up early, does homework, leaves for school");
		
	}
	
	
	
	
	
}
