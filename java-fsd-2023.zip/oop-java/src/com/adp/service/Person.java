package com.adp.service;

import java.time.LocalDate;

/**
 * 
 * @author sriniva1
 *
 * Generalization  is a form of  is-a relationship where one class (sub class) is a 
 * specialized form of another class(super class).
 * 
 * A sub class is a specialized form of super class. 
 * 
 * A super class is generalized form of sub classes.
 * 
 * public class SubClass extends SuperClass{
 * 
 * }
 * 
 * Note: Java doesn't allow multiple inheritance i.e a sub class cannot have more than
 * one super class.
 * 
 * Java supports multi-level( C -> B -> A) and hierarchical inheritance ( B->A, C->A, D->A)
 * 
 * A sub class inherits all the members( data members/methods) of its super. Even the
 * private members of super class are inherited into subclass. 
 * 
 * The methods of subclass cannot directly access private members of its super class.
 * 
 */

/**
 * 
 * @author sriniva1
 *  If a class has even one abstract method, then the class has to be declared as
 *  abstract.
 *  
 *  Abstract classes cannot be instantiated but can be a references pointing
 *  to instances of its subclasses.
 *  
 *  Person person= new Person() is ERROR.
 *  
 *  Person person= new Faculty() is valid
 */
public abstract class Person {
	private Long adharCard;
	private String name;
	private LocalDate birthdate;
	
	
	public Person() {
		
	}


	public Person(Long adharCard, String name, LocalDate birthdate) {
		super();
		this.adharCard = adharCard;
		this.name = name;
		this.birthdate = birthdate;
	}


	public Long getAdharCard() {
		return adharCard;
	}


	public void setAdharCard(Long adharCard) {
		this.adharCard = adharCard;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public LocalDate getBirthdate() {
		return birthdate;
	}


	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}


	@Override
	public String toString() {
		return "AdharCard=" + adharCard + ", name=" + name + ", birthdate=" + birthdate;
	}
	
	
	public void getDetails() {
		System.out.println(this.name + " was born on "+ this.birthdate);
	}
	
	
	//abstract method
	public abstract void dayToDayActivity();
}










