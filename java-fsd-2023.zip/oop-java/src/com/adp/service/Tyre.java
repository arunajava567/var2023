package com.adp.service;

//contained/part-of class
public class Tyre {
	private Integer size;
	private Integer aspectRatio;
	
	
	public Tyre() {
		super();
	}


	public Tyre(Integer size, Integer aspectRatio) {
		super();
		this.size = size;
		this.aspectRatio = aspectRatio;
	}


	public Integer getSize() {
		return size;
	}


	public void setSize(Integer size) {
		this.size = size;
	}


	public Integer getAspectRatio() {
		return aspectRatio;
	}


	public void setAspectRatio(Integer aspectRatio) {
		this.aspectRatio = aspectRatio;
	}


	@Override
	public String toString() {
		return "Tyre [size=" + size + ", aspectRatio=" + aspectRatio + "]";
	}
	
	
	
}
