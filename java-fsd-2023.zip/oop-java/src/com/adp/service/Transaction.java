package com.adp.service;

public interface Transaction {
	public abstract Double withdraw(Double amount);
	public abstract Double deposit(Double amount);
}
