package com.adp.service;

import java.util.Arrays;

/**
 * 
 * @author sriniva1
 *		Association: The relationship between objects of different classes.
 *
 *		Types of Association,
 *			Aggregation, Composition, Dependency, Generalization & Realization
 *
 * 	Aggregation & Composition
 * 		The relationship between objects of different classes is "has-a" relaiton ship.
 * 
 * 	    A class has data members of other class types.
 * 		Ex. If Library and Book are 2 classes, A Library "has a" list of Books,
 * 			
 * 		A Car "has-a" Engine, A Car has a data member of type, Engine.
 * 
 * 		Here class, Car is called as Container class and class, Engine is called
 * 		Contained class.
 * 
 * 		In UML terminology, Container class is called "whole-of" and Contained class
 * 		is called as "part-of".
 * 
 * 		Difference between Aggregation and Composition:
 * 
 * 		 	The life-cycle dependency of contained class objects is not dependent on
 * 			container class in Aggregation i.e. if container class object ceases to exist, 	
 * 			contained objects will not be destroyed.
 * 
 * 			Whereas in composition, The life-cycle dependency of contained class objects 
 * 			is dependent on container class i.e if container object is destroyed, contained
 * 			objects are also destroyed.
 * 
 * 	
 * 		
 * 
 */
// Aggregation Example
//Container/whole-of class
public class Car {
	private String carMake;
	private Engine engine;
	private Tyre tyres[];
	
	public Car() {
		
	}

	public Car(String carMake, Engine engine, Tyre[] tyres) {
		super();
		this.carMake = carMake;
		this.engine = engine;
		this.tyres = tyres;
	}

	public String getCarMake() {
		return carMake;
	}

	public void setCarMake(String carMake) {
		this.carMake = carMake;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public Tyre[] getTyres() {
		return tyres;
	}

	public void setTyres(Tyre[] tyres) {
		this.tyres = tyres;
	}

	@Override
	public String toString() {
		return "Car [carMake=" + carMake + ", engine=" + engine + ", tyres=" + Arrays.toString(tyres) + "]";
	}
	
	
	
}











