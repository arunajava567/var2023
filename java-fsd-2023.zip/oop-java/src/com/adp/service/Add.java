package com.adp.service;

@FunctionalInterface
public interface Add {
	public abstract Integer addition(Integer number1, Integer number2);
}
