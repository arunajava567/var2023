Marker/Tagged Interface:
	Empty interface is called marker interface.
	Can be used as a Type
	Built-in marker interfaces: Serializable, Cloneable
	
	user-defined marker interface, rarely applied
	public interface I{ }
	
Functional interface:
	An interface with only one abstract method is called functional interface
	Note: Lamdas are based on functional interfaces

	