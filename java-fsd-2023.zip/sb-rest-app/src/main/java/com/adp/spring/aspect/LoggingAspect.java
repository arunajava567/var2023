package com.adp.spring.aspect;

import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;



@Component
@Aspect
public class LoggingAspect {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@AfterThrowing(pointcut = "execution(* com.adp.spring.controller.*.*(..))", throwing = "exception")
	public void logServiceException(Exception exception) throws Exception {
		logger.error(exception.getMessage(), exception);
	}

}
