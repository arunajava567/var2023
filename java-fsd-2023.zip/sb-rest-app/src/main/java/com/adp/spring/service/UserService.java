package com.adp.spring.service;

import java.util.List;

import com.adp.spring.bean.User;
import com.adp.spring.exception.UserException;


public interface UserService {
	public abstract User getUserById(Integer userId) throws UserException;
	public abstract List<User> getAllUsers() throws UserException;
	public abstract User addUser(User user) throws UserException;
	public abstract User deleteUser(Integer userId) throws UserException;
	public abstract Integer updateUserEmail(Integer userId, String email) throws UserException;
	public abstract User updateUser(User user) throws UserException;
	
}
