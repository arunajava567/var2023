package com.adp.service;

import java.sql.SQLException;
import java.util.List;

import com.adp.dao.PersonDAO;
import com.adp.dao.PersonDaoImpl;
import com.adp.dto.Person;
import com.adp.exception.PersonException;

public class PersonServiceImpl implements PersonService{
	PersonDAO personDAO = new PersonDaoImpl();

	@Override
	public List<Person> getAllPersons() throws PersonException {
		try {
			return personDAO.getAllPersons();
		}catch(SQLException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

}
