package com.adp.dao;

import java.sql.SQLException;
import java.util.List;

import com.adp.dto.Person;

public interface PersonDAO {
	public abstract List<Person> getAllPersons() throws SQLException;
}
