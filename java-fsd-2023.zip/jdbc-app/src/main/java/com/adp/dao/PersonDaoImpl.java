package com.adp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.adp.dto.Person;
import com.adp.mapper.QueryMapper;
import com.adp.service.OracleConnection;

public class PersonDaoImpl implements PersonDAO {

	@Override
	public List<Person> getAllPersons() throws SQLException {
		
		try(
				Connection connection= OracleConnection.getConnection();
				Statement statement= connection.createStatement();
				){
			List<Person> personList= new ArrayList<>();
			ResultSet resultSet= statement.executeQuery(QueryMapper.GET_ALL_PERSONS);
			while(resultSet.next()) {
				Person person = new Person();
				person.setAdharCard(resultSet.getLong("adhar_card"));
				person.setName(resultSet.getString("name"));
				person.setBirthdate(resultSet.getDate("birthdate").toLocalDate());
				person.setAddress(resultSet.getString("address"));
				person.setMobile(resultSet.getLong("mobile"));
				person.setEmail(resultSet.getString("email"));
				personList.add(person);
			}
//			System.out.println(personList.size());
			return personList;
			
		}catch(SQLException e) {
//			e.printStackTrace();
			throw e;
		}
		
	}

}
