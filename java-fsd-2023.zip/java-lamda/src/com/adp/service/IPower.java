package com.adp.service;

@FunctionalInterface
public interface IPower {
	public abstract Long power(int b, int e);
}
