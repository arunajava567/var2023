package com.adp.service;

@FunctionalInterface
public interface Greeting {
	public abstract void greet();
}
