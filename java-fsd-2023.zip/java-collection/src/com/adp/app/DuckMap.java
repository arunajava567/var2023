package com.adp.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.adp.service.Duck;

public class DuckMap {

	public static void main(String[] args) {
		Map<String,Duck> duckMap = new HashMap<>();
		
		populateMap(duckMap);
		showMap(duckMap);

		String color="Grey";
		int num = countDucksByColor(duckMap,color);
		System.out.println("No. of ducks having color, "+color+" is "+num);
		
		List<String> breedList= getBreedsByColor(duckMap,color);
		System.out.println(breedList);
	}

	private static List<String> getBreedsByColor(Map<String, Duck> duckMap, String color) {
		List<String> breedList= new ArrayList<>();
		for(Map.Entry<String,Duck> d: duckMap.entrySet()) {
			if(d.getValue().getColor().equalsIgnoreCase(color)) {
				breedList.add(d.getValue().getBreed());
			}
		}
		return breedList;
	}

	private static void populateMap(Map<String, Duck> duckMap) {
		duckMap.put("Alabio",new Duck("Alabio","White",1.5));
		duckMap.put("Americn Pelican",new Duck("Americn Pelican","Grey",1.8));
		duckMap.put("Crested",new Duck("Crested","Black",2.5));
		duckMap.put("Indain Runner duck",new Duck("Indain Runner duck","White",3.5));
		duckMap.put("Call duck",new Duck("Call duck","Grey",1.7));
		
	}

	private static void showMap(Map<String, Duck> duckMap) {
		for(Map.Entry<String,Duck> d: duckMap.entrySet()) {
			System.out.println(d.getKey()+":"+ d.getValue());
		}
		
	}

	private static int countDucksByColor(Map<String, Duck> duckMap, String color) {
		int count=0;
		for(Map.Entry<String,Duck> d: duckMap.entrySet()) {
			if(d.getValue().getColor().equalsIgnoreCase(color)) {
				count++;
			}
		}
		return count;
	}

	
}
