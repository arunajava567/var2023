package com.adp.spring.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class CustomerAdvice {
	
//	@Pointcut("execution(* com.adp.spring.bean.Customer.get*(..))")
//	public void getterMethodsOfCustomer() {
//		
//	}
//	
//	@Before("getterMethodsOfCustomer()")
//	public void beforeGetAdvice(JoinPoint joinPoint) {
//		System.out.println("Before execution of getter methods of Customer class");		
//		System.out.println("Method Name: "+joinPoint.getSignature().getName());
//	}
//	
//	
//
//	@After("execution(* com.adp.spring.bean.Customer.set*(..))")
//	public void afterSetAdvice(JoinPoint joinPoint) {
//		System.out.println("After execution of setter methods");		
//		System.out.println("Method Name: "+joinPoint.getSignature().getName());
//	}
	
	
//	@Pointcut("execution(* com.adp.spring.bean.Customer.*(..))")
//	public void allMethodsOfCustomer() {
//		
//	}
//	
//	@Before("allMethodsOfCustomer()")
//	public void beforeGetAdvice(JoinPoint joinPoint) {
//		System.out.println("Before execution of a method of Customer class");		
//		System.out.println("Method Name: "+joinPoint.getSignature().getName());
//	}
//	
//	
//
//	@After("allMethodsOfCustomer()")
//	public void afterSetAdvice(JoinPoint joinPoint) {
//		System.out.println("After execution of a method methods");		
//		System.out.println("Method Name: "+joinPoint.getSignature().getName());
//	}
	
	
	
	
	
	
	
	@Pointcut("execution(* com.adp.spring.service.CustomerService.addCustomer(..))")
	public void addCustomerPointcut(){}
	
//	@Before("addCustomerPointcut()")
//	public void logBeforeAdvice(JoinPoint joinPoint) {
//		System.out.println("logBeforeAdvice() is running!");
//		System.out.println("hijacked : " + joinPoint.getSignature().getName());
//	}
//
//	@After("addCustomerPointcut()")
//	public void anotherLogAfterAdvice(JoinPoint joinPoint) {
//		System.out.println("anotherLogAfterAdvice() is running!");
//		System.out.println("hijacked : " + joinPoint.getSignature().getName());
//	}
	
	
	@Around("addCustomerPointcut()")
	public void aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("aroundAdvice(): Before addCustomer()");
		//explicitly invoking jointPoint method (addCustomer() )
		joinPoint.proceed();
		System.out.println("aroundAdvice(): After addCustomer()");
	}
	
}
