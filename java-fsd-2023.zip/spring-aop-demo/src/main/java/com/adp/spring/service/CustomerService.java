package com.adp.spring.service;

import com.adp.spring.bean.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);
}
