package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.adp.spring.bean.Customer;
import com.adp.spring.service.CustomerService;



public class App {
    public static void main( String[] args )    {
      ApplicationContext context=null;
      try {
    	  context= new ClassPathXmlApplicationContext("spring-aop.xml"); 
    	  Customer customer= (Customer) context.getBean("customerBean");
    	  System.out.println(customer.getCustomerName());
    	  System.out.println("--------------------------------------");
    	  customer.setCustomerName("Clarke");
    	  System.out.println("----------------------------------------");
    	  System.out.println(customer.getCustomerName());
    	  System.out.println("----------------------------------------");
    	  CustomerService service= (CustomerService) context.getBean("customerServiceBean");
    	  service.addCustomer(customer);
    	  
    	  ((AbstractApplicationContext)context).registerShutdownHook();
      }catch(Exception e) {
    	  e.printStackTrace();
      }finally {
    	  ((AbstractApplicationContext)context).close();
      }
    }
}
