export function parseJwt(token) {
  if (!token) { return }
  //token = header.payload.signature
  const base64Url = token.split('.')[1]
  /*
  Both Base64 and Base64url are ways to encode binary data in string form. 
  You can read about the theory of base64 here. The problem with Base64 is that it contains 
  the characters +, /, and =, which have a reserved meaning in some filesystem names and URLs. 
  So base64url solves this by replacing + with - and / with _. 
  */
  const base64 = base64Url.replace('-', '+').replace('_', '/')
  //pure javascript atob() function to decode token into a string
  return JSON.parse(window.atob(base64))
}

export const handleLogError = (error) => {
  if (error.response) {
    console.log(error.response.data)
  } else if (error.request) {
    console.log(error.request)
  } else {
    console.log(error.message)
  }
}