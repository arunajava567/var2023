const prod = {
  url: {
    API_BASE_URL: 'https://myapp.herokuapp.com',
  }
}

const dev = {
  url: {
    API_BASE_URL: 'http://localhost:8087'
  }
}

/*
NODE_ENV is a system environment variable that Node exposes into running scripts. 
It's used by convention to determine dev-vs-prod behavior, by both server tools, build scripts, 
and client-side libraries
*/
export const config = process.env.NODE_ENV === 'development' ? dev : prod