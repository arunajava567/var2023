Applications URLs

order-api	http://localhost:8087/swagger-ui.html	
order-ui	http://localhost:3000	

Application	URL	Credentials
admin/admin, user/user or signing up a new user

Note: the credentials shown in the table are the ones already pre-defined. You can signup new users