package com.sapient.asde.service;

import java.util.List;

public class PersonManager {
    /*
        following single state of responsibilty
     */
    public void showPersonDetailsOnConsole(List<Person> personList){
        //TO DO
    }
}
