package com.example.products.model;

public interface TestProduct {
	String getName();
	int getQty();
}
