package com.example.springdemo;

public interface IDemoService {

	public String sales();
	public String shipment();
}
