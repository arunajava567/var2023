# citibank-microservices-julybatch

To execute the services, first start the spring cloud config server, then followed by eureka, gateway, producer and consumer
services.

In the hello-config-server, I have my git uri, you replace this with your github uri and with your credentials if needed.

