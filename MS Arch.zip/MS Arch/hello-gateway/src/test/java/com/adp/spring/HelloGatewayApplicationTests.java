package com.adp.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
