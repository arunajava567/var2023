//package com.adp.spring.feign;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@FeignClient(name = "IDENTITY-MANAGEMENT-SERVICE")
//public interface IdentityManagementProxy {
//
//    @RequestMapping("/auth/validate")
//    public String validateToken();
//}
