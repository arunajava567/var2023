import { createContext } from "react";
const OfferLetterContext = createContext();
export default OfferLetterContext;
