import OfferLetterContext from '../context/OfferLetterContext'
import React, { useState, useEffect } from "react";
import { parseCookies } from "nookies";

const OfferLetterStates = (props) => {
  const cookies = parseCookies();
  console.log(cookies);
  const userData = cookies["UserDetails"] && JSON.parse(cookies["UserDetails"]);
  const [userDetails, setUserDetails] = useState(userData);
  
  
 


  return (
    <OfferLetterContext.Provider
      value={{
        userDetails,
        setUserDetails,
       
      }}
    >
      {props.children}
    </OfferLetterContext.Provider>
  );
};
export default OfferLetterStates;
