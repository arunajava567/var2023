import './App.css';
import Login from './components/Login';
import Sidebar from './components/Sidebar'

import OfferLetter from './components/OfferLetter';
import React, {useState} from 'react';
import Navbar from './components/Navbar';
import CandidateTable from './components/CandidateTable';
import SupportCards from './components/SupportCards';
import BarChart from './components/BarChart';
import Dashboard from './components/Dashboard';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Outlet,
} from "react-router-dom";

import { Suspense } from "react";
import Footer from './components/footer';
function DashboardLayout({ children}) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  return (
    <>
    <div className='relative '>

    
    <Navbar />
      <div className="flex flex-col justify-center items-center">
      {children}
       
      </div>
      <div className='absolute bottom-0'>
      <Footer/>
      </div>

</div>

{/* <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">

<div class="hidden md:block md:col-span-2.4 h-screen sticky top-0 bottom-0">
  <Sidebar />
</div>

<div class="col-span-12 md:col-span-9.6 bg-gray-200 w-full">
{children}
</div>

</div> */}
    </>
  );
}
const App=()=> {



  return (
    <>

    
    <Router> 
        <Routes>
          <Route
            path="/dashboard"
            element={
              <Suspense fallback={<p>Loading</p>}>
                <DashboardLayout >
                  <Outlet />
                </DashboardLayout>
              </Suspense>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="offerLetter" element={<OfferLetter />} />
            <Route path="CandidateTable" element={<CandidateTable />} />
            <Route path="analytics" element={<BarChart />} />
            <Route path="help" element={<SupportCards />} />
          </Route>


          <Route exact path="/" element={<Login />}></Route>


         
         
        </Routes>
      </Router>
   
    {/* <Login/>
    <OfferLetter/>
    <CandidateTable />
    <SupportCards/> */}
    {/* <BarChart/> */}
    </>
  );
}

export default App;









