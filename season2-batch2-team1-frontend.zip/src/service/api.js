import axios from "axios";

export const LoginCredential = async (data)=>{
        const response = await axios.post("http://localhost:8082/api/login",data)
        return response.data;
} 

export const getCandidataByRole = async(term)=>{
        
        const response = await axios.get(`http://localhost:8082/api/retrieve-candidates/${term}`);
        console.log()
        return response.data;
}
export const findAllCandidate = async(term)=>{
        const response = await axios.get(`http://localhost:8082/api/find-all`);
        console.log()
        return response.data;
}

export const generateLetters = async (term)=>{
        const response = await axios.get(`http://localhost:8082/api/letter-generated/${term}`)
        return response.data;
}

export const sendOfferLetter = async (id)=>{
        const response = await axios.get(`http://localhost:8082/api/database-save/${id}`);
        return response.data;
}
export const getCandidataByRoleSentDataNull = async (term)=>{

        const response = await axios.get(`http://localhost:8082/api/get-data/${term}`);
        // console.log(response)
        // console.log(response.data);
        return response.data;

  
};