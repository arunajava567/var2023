import React, { useState, useRef } from 'react';
import { generateLetters } from '../service/Api';
import { sendOfferLetter } from '../service/Api';
import { getCandidataByRoleSentDataNull } from '../service/Api'
import pdf from "../offer-letters-pdf/offerletter1.pdf"
import ModalComponent from './ModalComponent';



const OfferLetter = () => {

    const [toggle, setToggle] = useState(false)
    const [positionOfLetter, setPositionOfLetter] = useState();
    const [candidateId, setCandidateId] = useState();
    const [responseModal, setResponseModal] = useState();

    const [isModalOpen, setModalOpen] = useState(false);



    const handleCloseModal = () => {
        // Logic to close modal
        setModalOpen(false);
    };


    const handleGenerateOfferLetter = (data) => {

        generateLetters(data)
            .then((res) => {

                console.log(res)
                setResponseModal(res);

            })
            .catch((error) => {
                console.log("error in generating offer letters", error);
            })

        setModalOpen(true);
    }
    const handleChangeLetter = (e) => {
        const myVal = e.target.value;
        // console.log(myVal)
        setPositionOfLetter(myVal);
        console.log(positionOfLetter)

    }
    const handlePreview = () => {
        setToggle(!toggle)
        console.log("preview")
    }
    const handleSendLetter = async () => {
        await getCandidataByRoleSentDataNull(positionOfLetter)
            .then((res) => {
                console.log(res)
                setCandidateId(res[0].candidateId)
                sendOfferLetter(res[0].candidateId)

                    .then((response) => {

                        console.log(response)
                        setResponseModal(response);
                    })
                    .catch((error) => {
                        console.log("error in generating offer letters", error);
                    })
              

            })
            .catch((error) => {
                console.log("errr", error);
            })
        setModalOpen(true);
    }
    return (
        <>
            {responseModal && isModalOpen ? <ModalComponent isOpen={isModalOpen} onClose={handleCloseModal} responseModal={responseModal} /> : <div className='my-14 bg-gray-800 p-2 shadow-xl '>
                <div className="bg-white shadow-md rounded p-8 mb-4 w-[40rem] ">
                    <h2 className="text-2xl mb-4 w-full bg-gray-800 text-white text-center rounded-xl p-1">Generate Offer Letter</h2>

                    <div className="mb-4">
                        <label htmlFor="offerType" className="block text-gray-800 text-md font-bold mb-2">
                            Offer Type
                        </label>
                        <select
                            id="offerType"
                            name="offerType"
                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        >
                            <option value="offerLetter">Offer Letter</option>
                        </select>
                    </div>

                    <div className="mb-4">
                        <label htmlFor="jobRole" className="block text-gray-800 text-md font-bold mb-2">
                            Job Role
                        </label>
                        <select
                            id="jobRole"
                            name="jobRole"

                            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"

                            onChange={(e) => {
                                setPositionOfLetter(e.target.value)
                            }}
                        >
                            <option value="Member Technical">Member Technical</option>
                            <option value="developer">Developer</option>
                            <option value="devOps">DevOps</option>
                            <option value="cloud">Cloud</option>
                        </select>
                    </div>
                    <div>



                        <div className="flex items-center justify-between ">
                            <button
                                onClick={() => { handleGenerateOfferLetter(positionOfLetter) }}
                                type="button"
                                className=" text-white text-md font-bold bg-gray-800 py-2 px-4  focus:outline-none focus:shadow-outline rounded-md mr-2"
                            >
                                Generate Offer Letter

                            </button>
                            {/* <button
                                onClick={() => { handlePreview() }}
                                type="button"
                                className=" text-white text-md font-bold bg-gray-800 py-2 px-4 rounded-md focus:outline-none focus:shadow-outline mr-2"
                            >
                                Preview Offer Letter
                            </button> */}
                            <button
                                type="button"
                                onClick={handleSendLetter}
                                className=" text-white text-md font-bold bg-gray-800 py-2 px-4 rounded-md focus:outline-none focus:shadow-outline"
                            >
                                Send Letter
                            </button>

                        </div>
                    </div>


                </div>

            </div>}


        </>
    );
};


export default OfferLetter;
