import React from 'react';
import './ModalComponent.css'

const ModalComponent = ({ isOpen, onClose,responseModal }) => {
  return (
    <>
      {isOpen && (
        <div className='bg-gray-800 w-96 p-2 my-8 shadow-lg shadow-black ' >

          
            <div className='bg-white flex flex-col justify-center items-center h-96 gap-20'  >
              <div ><p className="text-7xl mb-8 text-center" >✅</p><p className=' text-3xl  font-bold'>
              {responseModal}
              </p></div>
              
              
              <button className='bg-red-700 text-white p-2 rounded-md w-20 text-xl  '  onClick={onClose}>
             Close
            </button>
            </div>

            
        
        </div>
      )}
    </>
  );
};

export default ModalComponent;
