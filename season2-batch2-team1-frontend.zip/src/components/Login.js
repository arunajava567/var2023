import React,{useContext,useState} from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { LoginCredential } from '../service/Api';
import { setCookie,parseCookies,destroyCookie } from 'nookies';
import OfferLetterContext from '../context/OfferLetterContext';
import { useNavigate } from 'react-router-dom';
import ADP from "../assests/ADP.jpg"
import loginImg from "../assests/loginbg.jpg"
const Login = () => {
    const navigate=useNavigate();
    const [notValid,setNotValid]=useState();
    const {userDetails,setUserDetails}=useContext(OfferLetterContext)

    const validationSchema = Yup.object().shape({
    email: Yup.string().required('Email is required'),
    password: Yup.string().required('Password is required'),
  });


  const initialValues = {
    email: '',
    password: '',
  };

  const onSubmit = (values) => {

    console.log('Login values:', values);
    LoginCredential(values).then((res)=>{
        console.log(res);
        setCookie(null,"UserDetails",JSON.stringify(res),{
            maxAge:2*60*60,
        })
        setUserDetails(res)

        const cookies=parseCookies()
        console.log(cookies["UserDetails"])
        console.log(userDetails)
        res.emailId ===null ? setNotValid("INVALID USER ID AND PASSWORD") :   navigate("/dashboard")
        

    })
    .catch((error)=>{
        console.log(error)
    })
  };

  return (
    <>
    <div className='relative'>

   
 <img src={loginImg} alt="login image"  className='w-full h-100vh bg-cover aspect-video'/>
    <div className=" absolute top-40 right-24 flex justify-center items-center bg-white rounded-xl  opacity-95 shadow-md shadow-white p-4 ">
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        <Form className="  rounded px-8 pt-6 pb-8 mb-4  h-96 w-96 ">
        <div className=' h-24 w-24'>
            <img src={ADP} alt="adp_logo" className=''/>
          </div>
          <h2 className="text-2xl mb-4 text-center font-bold ">SIGN IN</h2>
          
          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-700 text-sm font-bold mb-2">
              Email
            </label>
            <Field
              type="text"
              id="email"
              name="email"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            />
            <ErrorMessage name="username" component="p" className="text-red-500 text-xs italic" />
          </div>
          <div className="mb-2">
            <label htmlFor="password" className="block text-gray-700 text-sm font-bold mb-2">
              Password
            </label>
            <Field
              type="password"
              id="password"
              name="password"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            />
            <ErrorMessage name="password" component="p" className="text-red-500 text-xs italic" />
          </div>
          <div className='text-red-700 text-md mb-2 '>
{notValid ? notValid :" "}
          </div>
          <div className="flex items-center justify-between">
            <button
              type="submit"
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Sign In
            </button>
          </div>
        </Form>
      </Formik>
    </div>
    </div>
    </>
  );
};

export default Login;
