import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhone, faEnvelope, faAddressBook, faAddressCard } from '@fortawesome/free-solid-svg-icons';

const SupportCards = () => {
  return (
    <div className="container mx-auto my-24 ">
      {/* Call Support Card */}
      <div className=' flex justify-center items-center bg-gray-800 p-2 mx-20 rounded-md shadow-lg'>

     
      <div className="bg-white  shadow-md rounded p-8 m-4 max-w-xs w-full">
      <a href="tel:9306660231" style={{textDecoration:"none",all:"unset"}}>
        <FontAwesomeIcon icon={faPhone} className="text-4xl mb-4 text-blue-500" />
        </a>
        <h2 className="text-xl font-bold mb-4">Call Support</h2>
        <p className="text-gray-700">Phone Number: +91-898762617</p>
      </div>

      {/* Email Support Card */}
      <div className="bg-white shadow-md rounded p-8 m-4 max-w-xs w-full">
      <a href="mailto:yash.mangla@adp.com" style={{textDecoration:"none",all:"unset"}}> 
        <FontAwesomeIcon icon={faEnvelope} className="text-4xl mb-4 text-green-500" />
        </a>
        <h2 className="text-xl font-bold mb-4">Email Support</h2>
        <p className="text-gray-700">Email: adp@help.com</p>
      </div>
      <div className="bg-white  shadow-md rounded p-8 m-4 max-w-xs w-full">
       <FontAwesomeIcon icon={faAddressCard} className="text-4xl mb-4 text-blue-500" />
       
        <h2 className="text-xl font-bold mb-4">Technical Support</h2>
        <p className="text-gray-700">Floor: 10th </p>
      </div>
      </div>
    </div>
  );
};

export default SupportCards;

