import React ,{useContext} from 'react';
import ADP from '../assests/ADP-logo.png'
import OfferLetterContext from '../context/OfferLetterContext';
import avat from '../assests/Letter.png'
import { destroyCookie } from 'nookies';
import { useNavigate } from "react-router-dom";
const Navbar = () => {
  const navigate = useNavigate();
  const handleClick = (e) => {
    const myVal = e.target.value;
    if (myVal === "Offer Letter") {
      navigate("/dashboard/offerLetter");
    }
    else if (myVal === "Help") {
      navigate("/dashboard/Help")
    }
    else if(myVal==="Analytics"){
      navigate("/dashboard/Analytics")
    }
  }
  const {userDetails,setUserDetails}=useContext(OfferLetterContext)
  return (
    <nav className="shadow-xl bg-gray-900 shadow-gray-400 p-4 flex justify-between items-center w-screen">
      <div>
        <img src={ADP} alt="Logo" className="h-8 ml-4" />
      </div>
      <div className='flex flex-row justify-around w-[28rem] items-center  text-md font-bold'>
      <button value="Home" onClick={()=>navigate("/dashboard")} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Home
        </button>
        <button value="Offer Letter" onClick={handleClick} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Offer Letter
        </button>
      
        <button value="Help" onClick={handleClick} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Help
        </button>
        <button value="Analytics" onClick={handleClick} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Analytics
        </button>
        <button value="Logout" onClick={() => {
          destroyCookie(null, "userData");
          navigate("/");
        }} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Logout
        </button>
      </div>
      <div className="flex items-center">
      <a href="mailto:yash.mangla@adp.com" style={{textDecoration:"none",all:"unset"}}> 
        <img
          src={avat}
          alt="Avatar"
          className="h-9 w-9 rounded-full mr-3"
        />
        </a>
        <span className="text-white font-bold mr-6">{userDetails?.name}</span>
      </div>
    </nav>
  );
};

export default Navbar;
