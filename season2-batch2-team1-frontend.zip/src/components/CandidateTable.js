import React, { useState, useEffect, useContext } from 'react';
import OfferLetterContext from '../context/OfferLetterContext';
import { getCandidataByRole, findAllCandidate } from '../service/Api';

const CandidateTable = () => {

  const [allData, setAllData] = useState([]);
  const [myData, setMyData] = useState([]);

  const {UserDetails}=useContext(OfferLetterContext)
 

  useEffect(() => {
    findAllCandidate().then((res) => {
      console.log(res);
      setAllData(res);
  
    })
      .catch((err) => {
        console.log("error in generating offer letters", err);
      })
  
  },[UserDetails])

  const myRoleFunc = (myCurrRole) => {
    getCandidataByRole(myCurrRole).then((res) => {
      console.log(myCurrRole)
      setMyData(res);
  
    })
      .catch((err) => {
        console.log("error in generating offer letters", err);
      })
  }



  return (
    <div className="w-full px-8  my-12">



      <div className="flex mb-8 w-64">

        <label htmlFor="jobRole" className="block text-gray-700  font-bold w-32 pt-1.5 text-md ">
          Job Role
        </label>
        <select
          id="jobRole"
          name="jobRole"
          className=" shadow appearance-none border rounded w-full py-2 px-3 text-black font-semibold leading-tight focus:outline-none 
                        bg-gray-300 focus:shadow-outline"
          onChange={(e) => {

            myRoleFunc(e.target.value)

          }}
        >
          <option value="Member Technical">Member Technical</option>
          <option value="Developer">Developer</option>
          <option value="DevOps">DevOps</option>
          <option value="Cloud">Cloud</option>
        </select>
      </div>


      <div className='p-4 shadow-xl bg-gray-300'>
        <table className="min-w-full border border-gray-300 bg-white  ">
          <thead>
            <tr>
              <th className="border p-2 w-32">Candidate ID</th>
              <th className="border p-2 w-72">Role</th>
              <th className="border p-2 w-56">Name</th>
              <th className="border p-2">Email ID</th>
              <th className="border p-2">Grade</th>
              <th className="border p-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {myData.length>0 ? myData.map((candidate) => (
              <tr key={candidate.candidateId}>
                <td className="border p-2">{candidate.candidateId}</td>
                <td className="border p-2">{candidate.role}</td>
                <td className="border p-2">{candidate.name}</td>
                <td className="border p-2">{candidate.emailId}</td>
                <td className="border p-2">{candidate.grade}</td>
                <td className="border p-2">{candidate.status ? candidate.status : "Not Sent"}</td>
              </tr>
           
              )):  allData.map((candidate) => (
                <tr key={candidate.candidateId}>
                  <td className="border p-2">{candidate.candidateId}</td>
                  <td className="border p-2">{candidate.role}</td>
                  <td className="border p-2">{candidate.name}</td>
                  <td className="border p-2">{candidate.emailId}</td>
                  <td className="border p-2">{candidate.grade}</td>
                  <td className="border p-2">{candidate.status ? candidate.status : "Not Sent"}</td>
                </tr>
             
                )) }
          </tbody>
        </table>
      </div>

    </div>
  );
};

export default CandidateTable;
