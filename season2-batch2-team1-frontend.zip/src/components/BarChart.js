import React, { useEffect, useRef,useState } from 'react';
import Chart from 'chart.js/auto';
import { useContext } from 'react';
import OfferLetterContext from '../context/OfferLetterContext';
import { findAllCandidate } from '../service/Api';
const BarChart = () => {
  const chartRef = useRef(null);


  const {UserDetails}=useContext(OfferLetterContext)
 

  const [allData, setAllData] = useState([]);

  useEffect(() => {
    findAllCandidate().then((res) => {
      console.log(res);
     const myPieData=res.reduce((acc,obj)=>{
      const role=obj.role;
      acc[role]=(acc[role] || 0)+1;
      return acc;
     },[])
     console.log(myPieData)
      setAllData(res);
  
    })
      .catch((err) => {
        console.log("error ", err);
      })
    const ctx = chartRef.current.getContext('2d');

    const data = {
      labels: ['Member Technical', 'Developer',"DevOps" ,'Cloud'],
      datasets: [
        {
          data: [4, 2, 5,6],
          backgroundColor: ['#ff6384', '#36a2eb', '#ffce56','red'],
        },
      ],
    };

    new Chart(ctx, {
      type: 'pie',
      data: data,
    });
  }, [UserDetails]);

  return <>
  <div className='w-[26rem] mt-16 shadow-xl p-4 rounded-lg shadow-gray-800'>
  <canvas ref={chartRef} width={400} height={400}></canvas>
  </div>
 
  </>
};

export default BarChart;
