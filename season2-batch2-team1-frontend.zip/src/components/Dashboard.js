import React from 'react'
import CandidateTable from './CandidateTable'
export default function Dashboard() {
  return (
    <><CandidateTable/></>
  )
}
