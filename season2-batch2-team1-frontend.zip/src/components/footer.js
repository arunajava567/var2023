import React from 'react'

export default function footer() {
  return (
    <div className='fixed text-center p-4 bottom-0 left-0 w-full text-white text-md font-bold  bg-gray-800'>&copy; 2023 ADP PVT LTD. All Rights Reserved</div>
  )
}
