import { useNavigate } from "react-router-dom";
import React, { useState } from 'react'
import { destroyCookie } from 'nookies';
export default function Sidebar({ isSidebarOpen, setIsSidebarOpen }) {
  const handleToggle = () => {
    setIsSidebarOpen((prev) => !prev);
  }
  const navigate = useNavigate();
  const handleClick = (e) => {
    const myVal = e.target.value;
    if (myVal === "Offer Letter") {
      navigate("/dashboard/offerLetter");
    }
    else if (myVal === "Help") {
      navigate("/dashboard/Help")
    }
  }
  return (
    <>
      <button onClick={
        handleToggle}>Toggle Sidebar</button>
      <div
        className={`fixed inset-y-0 left-0 w-64 bg-gray-800 p-4 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } transition-transform ease-in-out`}
      >
        <button value="Home" onClick={navigate("/dashboard")} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Home
        </button>
        <button value="Offer Letter" onClick={handleClick} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Offer Letter
        </button>
        {/* <button value="Analytics" onClick={onClose} className="text-white block p-2 mb-2 hover:bg-gray-700">
        Analytics
      </button> */}
        <button value="Help" onClick={handleClick} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Help
        </button>
        <button value="Logout" onClick={() => {
          destroyCookie(null, "userData");
          navigate("/");
        }} className="text-white block p-2 mb-2 hover:bg-gray-700">
          Logout
        </button>
      </div>
    </>
  );
};