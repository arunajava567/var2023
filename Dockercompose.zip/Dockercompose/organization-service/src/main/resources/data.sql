create table organizations(id number primary key,name varchar(20),address varchar(20));

INSERT INTO organizations  VALUES(1, 'ABC', 'ALex');
INSERT INTO organizations  VALUES(2, 'XYZ', 'Cairo'),
INSERT INTO organizations  VALUES(3, 'BNM', 'Cairo');
