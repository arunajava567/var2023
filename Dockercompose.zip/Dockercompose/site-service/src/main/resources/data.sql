create table sites (id number primary key,organization_id references organizations(id) , name varchar(20));

INSERT INTO sites VALUES	(1, 1, 'Operations');
INSERT INTO sites VALUES	(2, 1, 'Development');
INSERT INTO sites VALUES	(3, 2, 'analysis');
INSERT INTO sites VALUES	(4, 3, 'Development');


create table organizations(id number primary key,name varchar(20),address varchar(20));

INSERT INTO organizations  VALUES(1, 'ABC', 'ALex');
INSERT INTO organizations  VALUES(2, 'XYZ', 'Cairo'),
INSERT INTO organizations  VALUES(3, 'BNM', 'Cairo');


create table users(id number primary key, organization_id number references organizations(id),site_id number references sites(id),
       name varchar(20), email varchar(10), phone varchar(10), position varchar(10));

INSERT INTO users VALUES (1, 1, 1, 'Sayed Mohamed', 'sayed@test.com', '010123456789', 'Manager');
INSERT INTO users VALUES(2, 1, 2, 'Ahmed Mahmoud', 'ahmed@teat.com', '01097654321', 'Developer');
INSERT INTO users VALUES(3, 2, 3, 'Mohammad Ali', 'mohammad@test.com', '010678954321', 'Analyst');
INSERT INTO users VALUES(4, 3, 4, 'Hamada Ibrahim', 'hamada@test.com', '010531247896', 'Developer');
INSERT INTO users VALUES(5, 2, 3, 'Tamer Hassen', 'tamer@test.com', '010975874321', 'Analyst');


