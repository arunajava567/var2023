INSERT INTO `users` (`id`, `organization_id`, `site_id`, `name`, `email`, `phone`, `position`) VALUES
	(1, 1, 1, 'Sayed Mohamed', 'sayed@test.com', '010123456789', 'Manager'),
	(2, 1, 2, 'Ahmed Mahmoud', 'ahmed@teat.com', '01097654321', 'Developer'),
	(3, 2, 3, 'Mohammad Ali', 'mohammad@test.com', '010678954321', 'Analyst'),
	(4, 3, 4, 'Hamada Ibrahim', 'hamada@test.com', '010531247896', 'Developer'),
	(5, 2, 3, 'Tamer Hassen', 'tamer@test.com', '010975874321', 'Analyst');
