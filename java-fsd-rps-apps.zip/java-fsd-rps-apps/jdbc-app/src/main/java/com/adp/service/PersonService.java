package com.adp.service;

import java.util.List;

import com.adp.dto.Person;
import com.adp.exception.PersonException;

public interface PersonService {
	public abstract List<Person> getAllPersons() throws PersonException;
}
