package com.adp.service;

import java.io.FileReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class OracleConnection {
	private static Properties properties=null;
    //>= JDBC API 4 , JDBC drivers are implicitly loaded
    //Load PostgreSQL driver explicitly for downward compatibility
    static {
        try {
            properties= new Properties();
            Reader reader=
                    new FileReader("C:\\Users\\sriniva1\\Documents\\adpws\\jdbc-app\\src\\main\\resources\\jdbc.properties");
            properties.load(reader);

            Class.forName(properties.getProperty("db.driver.name"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(properties.getProperty("db.conn.url"),properties.getProperty("db.username"), properties.getProperty("db.password"));
    }

    public static void testConnection(){
        try {
            Connection connection = getConnection();
            /*
             * JDBC provides support 5 transaction isolation levels through Connection interface.
				
				TRANSACTION_NONE: It is represented by integer value 0 does not support transactions.
				TRANSACTION_READ_COMMITTED: It is represented by integer value 2 supports transactions allowing Non-Repeatable Reads and, Phantom Reads.
				TRANSACTION_READ_UNCOMMITTED: It is represented by integer value 1 supports transactions allowing Dirty Reads, Non-Repeatable Reads and, Phantom Reads.
				TRANSACTION_REPEATABLE_READ: It is represented by integer value 4 supports transactions allowing only Phantom Reads.
				TRANSACTION_SERIALIZABLE: It is represented by integer value 8 supports transactions without allowing Dirty Reads, Non-Repeatable Reads and, Phantom Reads.
             */
            System.out.println(connection.getSchema());
            System.out.println(connection.getTransactionIsolation());
        }catch(SQLException e){
            e.printStackTrace();
        }

    }
}
