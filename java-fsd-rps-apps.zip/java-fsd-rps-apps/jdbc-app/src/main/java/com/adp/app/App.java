package com.adp.app;

import java.util.List;

import org.apache.log4j.Logger;

import com.adp.dto.Person;
import com.adp.exception.PersonException;
import com.adp.service.PersonService;
import com.adp.service.PersonServiceImpl;

public class App {
	public static PersonService personService= new PersonServiceImpl();
	public static  final Logger logger = Logger.getLogger(App.class);
	
	
	public static void main( String[] args ){
		
		
//		OracleConnection.testConnection();
		
				try {
					List<Person> personList= personService.getAllPersons();
					personList.stream().forEach(System.out::println);
					logger.info(personList);
				}catch(PersonException e) {
//					e.printStackTrace();
					logger.error(e);
				}


//				try(
//						Connection connection= OracleConnection.getConnection();
//						PreparedStatement preparedStatement= connection.prepareStatement(QueryMapper.GET_PERSON_BY_ID);
//						){
//					preparedStatement.setLong(1,123456789234L);
//					ResultSet resultSet= preparedStatement.executeQuery();
//					if(resultSet.next()) {
//						Person person = new Person();
//						person.setAdharCard(resultSet.getLong("adhar_card"));
//						person.setName(resultSet.getString("name"));
//						person.setBirthdate(resultSet.getDate("birthdate").toLocalDate());
//						person.setAddress(resultSet.getString("address"));
//						person.setMobile(resultSet.getLong("mobile"));
//						person.setEmail(resultSet.getString("email"));
//						System.out.println(person);
//					}else {
//						System.out.println("No records in the table");
//					}
//		
//				}catch(SQLException e) {
//					e.printStackTrace();
//		
//				}

	}
}
