package com.adp.exception;

public class PersonException extends Exception {

	public PersonException() {

	}

	public PersonException(String message) {
		super(message);
	}
	
	public PersonException(String message, Throwable t) {
		super(message,t);
	}
}
