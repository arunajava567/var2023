package com.adp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.model.Person;

@Service
public class PersonService {
	@Autowired
	private Person person;
	
	public void showPerson() {
		System.out.println(person);
		
	}
}
