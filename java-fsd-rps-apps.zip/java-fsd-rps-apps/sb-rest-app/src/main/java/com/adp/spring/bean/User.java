package com.adp.spring.bean;

import java.time.LocalDate;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class User {
	private Integer userId;
	
	@Size(min = 4)
	private String password;
	
	@NotNull(message = "{user.name.absent}")
	@Pattern(regexp = "[A-Za-z]+(\\s[A-Za-z]+)*", message = "{user.name.invalid}")
	private String name;
	@Email(message = "{user.email.invalid}")
	private String email;
	@PastOrPresent(message="{user.birthdate.invalid}")
	private LocalDate birthdate;
	@NotNull(message = "{user.profession.absent}")
	private String profession;
	
}







	