package com.adp.spring.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.adp.spring.bean.User;
import com.adp.spring.exception.UserException;
import com.adp.spring.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1")
public class UserController {
	
//	private Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;
	

	@GetMapping("/hello")
	public String sayHello() {
		return "Hello! Welcome to Spring REST";
	}

	// http://localhost:8082/api/v1/users/1
	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUser(@PathVariable Integer id) {
		try {
			User user = userService.getUserById(id);
			return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
		}catch(UserException e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}catch(Exception e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
		
	}

	// http://localhost:8082/api/v1/users
	@GetMapping("/users")
	public ResponseEntity<List<User>> getAllUsers(){
		try {
			List<User> userList = userService.getAllUsers();
			return new ResponseEntity<>(userList, HttpStatus.OK);
		}catch(UserException e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}catch(Exception e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}

	// http://localhost:8082/api/v1/users
	@PostMapping("/users")
	public ResponseEntity<User> addUser(@Valid @RequestBody User user,
			BindingResult bindingResult) {
		try {
			if(bindingResult.hasErrors()) {
				throw new UserException(bindingResult.getAllErrors().toString());
			}
			User newUser = userService.addUser(user);
			return new ResponseEntity<>(newUser, HttpStatus.OK);
		}catch(UserException e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}catch(Exception e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
		
	}

	
	// http://localhost:8082/api/v1/users
	@DeleteMapping("/users/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable Integer id) {
		try {
			User deletedUser= userService.deleteUser(id);
			return new ResponseEntity<>(deletedUser, HttpStatus.OK);
		}catch(UserException e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}catch(Exception e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}


	/*
	 * A method that updates email of the given userid.
	 * The method accepts userId and email as Request parameters
	 */
	//http://localhost:8082/api/v1/users?id=1&email=smith1@gmail.com
	
	@PutMapping("/users")
	public ResponseEntity<Integer> updateEmail(@RequestParam(name = "id",required = true) Integer id, 
			@RequestParam(name = "email",required = true) String email) {
		try {
			Integer userId = userService.updateUserEmail(id, email);
			return new ResponseEntity<>(userId, HttpStatus.OK);
		}catch(UserException e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}catch(Exception e) {
//			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}

	
		//http://localhost:8082/api/v1/update-user
	
		@PutMapping("/update-user")
		public ResponseEntity<User> updateUser(@Valid @RequestBody User user) {
			try {
				User updatedUser= userService.updateUser(user);
				return new ResponseEntity<>(updatedUser, HttpStatus.OK);
			}catch(UserException e) {
//				logger.error(e.getMessage());
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
			}catch(Exception e) {
//				logger.error(e.getMessage());
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
			}
		}


}
