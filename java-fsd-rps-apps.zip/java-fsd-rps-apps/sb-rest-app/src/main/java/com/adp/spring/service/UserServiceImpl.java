package com.adp.spring.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.adp.spring.bean.User;
import com.adp.spring.exception.UserException;

@Service
public class UserServiceImpl implements UserService{
	
	private static  List<User> userList= new ArrayList<>();
	private static Integer counter=1;
	
	static {
		userList.add(new User(counter++,"smith@123","Smith","smith@gmail.com",LocalDate.of(1990, 10, 15),"Developer"));
		userList.add(new User(counter++,"clarke@123","Clarke","clarke@gmail.com",LocalDate.of(1991, 1, 10),"Tester"));
		userList.add(new User(counter++,"jones@123","Jones","jones@gmail.com",LocalDate.of(1985, 11, 11),"Developer"));
		userList.add(new User(counter++,"john@123","John","john@gmail.com",LocalDate.of(1980, 5, 5),"Manager"));
		userList.add(new User(counter++,"ravi@123","Ravi","ravi@gmail.com",LocalDate.of(1995, 1, 10),"Tester"));

	}

	

	@Override
	public User getUserById(Integer userId) throws UserException {
		try {
			User user = userList.stream().filter(u->u.getUserId().equals(userId)).collect(Collectors.toList()).get(0);
			if(user == null) {
				throw new UserException("Invalid UserId");
			}
			
			return user;
		}catch(Exception e) {
			throw new UserException(e.getMessage());
		}
		
	}

	@Override
	public List<User> getAllUsers() throws UserException {
		try {
			if(userList.size()==0) {
				throw new Exception("User list is empty");
			}
			
			return userList;
		}catch(Exception e) {
			throw new UserException(e.getMessage());
		}

		
	}

	@Override
	public User addUser(User user) throws UserException {
		try {
			user.setUserId(counter++);
			
			if(userList.add(user) == true) {
				return user;
			}else {
				throw new UserException("Unable to add user");
			}
		}catch(Exception e) {
			throw new UserException(e.getMessage());
		}
		
	}

	@Override
	public User deleteUser(Integer userId) throws UserException {
		try {
			int sizeBefore= userList.size();
			userList = userList.stream().filter(u->u.getUserId()!= userId).toList();
			if(userList.size() <sizeBefore) {
				return this.getUserById(userId);
			}else {
				return null;
			}
		}catch(Exception e) {
			throw new UserException(e.getMessage());
		}
		
	}

	@Override
	public Integer updateUserEmail(Integer userId, String email) throws UserException {
		try {
			User user = userList.stream().filter(u->u.getUserId().equals(userId)).collect(Collectors.toList()).get(0);

			if(user!=null) {
				user.setEmail(email);
				int index = userList.indexOf(user);

				userList.set(index, user);
				return userId;
			}else {
				return null;
			}
		}catch(Exception e) {
			throw new UserException(e.getMessage());
		}
		
	}

	@Override
	public User updateUser(User user) throws UserException {
		try {
			User userFromList = userList.stream()
						.filter(u->u.getUserId().equals(user.getUserId()))
						.collect(Collectors.toList()).get(0);

			if(userFromList!=null) {
				
				int index = userList.indexOf(userFromList);

				userList.set(index, user);
				return user;
			}else {
				return null;
			}
		}catch(Exception e) {
			throw new UserException(e.getMessage());
		}
	}

}
