Java core libraries/packages and important classes in these packages

java.lang package
	classes:
		Object, Class, System, Math, String, StringBuffer, StringBuilder
java.util
		Scanner, Date, Calendar, GregorianCalendar, Arrays
		Collection Fraemwork classes: ArrayList, HashSet, LinkedHashSet, TreeSet
									  HashMap, LinkedHashMap, TreeMap
java.time
		LocalDate, LocalTime, LocalDateTime

java.sql

-----------------------------------------------------------------------------------
1. Object class

	This is the root class i.e parent for all the classes
	The methods of this class is inherited into all the classes.
	
	Methods:
			clone() : to create clone/replica of an object
			getClass(): returns class name of the object at runtime
			hashCode(): returns hashCode of an object which is an integer value.
			
			Note: By default, every object has a unique hashCode. If 2 objects
			have same state and if they need to have same hashcode, we need to explicitly
			override equals() and hashCode() methods.	
	
			Note: State of an object?
			
			Current values in the instance variables of an object represents
			the state of an object.
			
			Every object has its own copy of instance variables while all the
			instances of a class will share a single copy of class/static variables.
			
			equals() : returns true is 2 objects have same state else returns false
			
			toString() : returns String representation of an object
			
			Thread related methods:
				notify(), notifyAll(), wait()
				
				
				
	2. String class
	
		equals() and hashCode() methods are overridden in String class. 
		Hence if 2 String objects have same state, they return same hashCode
		and equals() returns true.
		
		Since String class has already overridden toString(), when the string object
		reference is placed in println(), state of string object is displayed.
		
		Objects of String class are immutable ie. state of String objects cannot
		be changed.
		
			String s1="hello";
			s1= "hellooo";
			syso(s1) ; 
			
			output? hellooo
		
		
			String pool: Part of heap. When String literal is assigned to String reference,
			the String literal is placed in String pool.
			If another String reference has same String literal assigned to it,
			JVM will not allocate separate memory in the String pool instead refers to
			same String literal.
	
					String s1= "Hello;
					String s2= "Hello";
	
					syso( s1==s2); true
					
					
					String s3= new String("Hello");
					String s4= new String("Hello");
					syso(s3==s4); //false
	
	
		String objects are immutable. Since they are immutable, they are also
		thread-safe.
		
		StringBuffer objects are mutable and thread-safe while StringBuilder objects
		are mutable but not thread-safe.
		
		Note: The methods of StringBuffer class are synchronized while the methods
				of StringBuilder class are not synchronized. This is the only difference
				between these two classes. StringBuilder class is replica of StringBuffer class.
				
				
			
			String class &  StringBuffer class methods
			
			String class methods:
				length(), contains(), matches(), split(), substr(), valueOf()
				
			StringBuffer class methods:
				append(), insert() , delete(), reverse()
				
			Regular Expressions for Patterns:
			
				
				
				
					
				
				
				
				
				
				
				
				
			
			
	
	
	
	
	
	
	
	
	
	
	
	
			
			
			
			
			
		

