package com.adp.util;

/**
 * 
 * @author Srini
 * 
 * This is a utility class which contains static/class methods which can be to
 * solve formula-based computations.
 *
 */
public class MyMath {
	
	/**
	 * 
	 * @param receives an integer value
	 * @return factorial as long integer
	 */
	public static long factorial(int n) {
		long fact=1;
		while(n>0) {
			fact = fact * n;
			n--;
		}
		return fact;
	}

}
