package com.adp.app;

import java.util.Scanner;

/**
 * 
 * @author sriniva1
 * This class demonstartes use of Scanner class.
 * This class belongs to java.util package
 */
public class ScannerDemo {
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
//		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Whats your age: ");
		int age = scanner.nextInt();
		System.out.println("OK, your age is "+ age);
		
		scanner.nextLine(); //clears the KBD buffer
		
		System.out.println("Hi, Whats your name");
		String name = scanner.nextLine();
		System.out.println("Hello, "+ name);
		

	}

}
