package com.adp.app;

import java.util.Arrays;
import java.util.Scanner;

/**
 * 
 * @author sriniva1
 *
 */
public class ArraysUtilDemo {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("How many students? ");
		int size = Integer.parseInt(scanner.nextLine());
		
		String names[] = new String[size];
		
		getStudentNames(names);
		
		System.out.println("Original list of names...");
		showStudentNames(names);
		
		
//		Arrays.sort(names);
//		
//		System.out.println("Sorted list of names...");
//		showStudentNames(names);
		
		int index = Arrays.binarySearch(names, "Vindhya");
		System.out.println(index);
			
		
	}

	private static void showStudentNames(String[] names) {
		for(String s : names) {
			System.out.println(s);
		}
	}

	private static void getStudentNames(String[] names) {
		for(int i=0; i<names.length;i++) {
			System.out.println("Enter name of student: "+ (i+1));
			names[i]= scanner.nextLine();
		}
	}

}
