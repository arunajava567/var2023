package com.adp.app;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * 
 * @author sriniva1
 	Supplier<T>    		T get()
    Consumer<T>    		void accept(T t)
    BiConsumer<T,U>     void accepts(T t, U u)
    Predicate<T>		Boolean test<T t)
    BiPredicate<t,U>    Boolean test<T t, U u)
    Function<T,R>       R apply(T t)
    BiFunction<T,U,R>	R apply(T t, U u)
    
    Method Reference (::)
    Shorthand of writing Lamda expression
    
    Consumer<String> consumer= (String string)-> System.out.println(string);
    					Same as
    
    Consumer<String> consumer = System.out::println;
    
    consumer.accept("Hello World!");
 */
public class BuiltinFITest {

	public static void main(String[] args) {
//		Consumer<String> consumer = (String str)-> System.out.println(str);
//		Consumer<String> consumer = (str)-> System.out.println(str);
		Consumer<String> consumer = str-> System.out.println(str);
		consumer.accept("Hello, Welcome to Lamdas");
		
		Consumer<String> c = System.out::println;
		c.accept("Hello World!");
		
		Supplier<String> supplier = () -> "Hi, How are you";
		System.out.println(supplier.get());
		
		consumer.accept(supplier.get());
		
//		Predicate<Integer> predicate= (num)-> (num%2==0)?true:false;
		Predicate<Integer> predicate= (num)-> num%2==0;
		System.out.println(predicate.test(15));
		

		BiFunction<Integer,Integer,Integer> biFunction = (n1,n2)-> (n1>n2)?n1:n2;
		System.out.println(biFunction.apply(100, 150));
		
		/*
		 *  a. implement factorial of given number : Function<T>
		 *  b. method that receives userid and password, returns true
		 *     if user id is adp and password is adp@123 : BiPredicate<T,U>
		 *  c. implement a to the power of b : BiFunction<T,U>
		 *  d. method that takes a line of text and displays alternate letters. : Consumer<T>
		 *  e. method that returns current date and time in milliseconds : Supplier
		 * 
		 */
		
		Supplier<Long> s = () -> System.currentTimeMillis();
		// Java base time line is 01-01-1970 00:00:00 GMT, also called as EPOCH
		// 1000 milli seconds is 1 second
		System.out.println("Current time in milliseconds is "+ s.get());
		
	}

}
