package com.adp.app;

import java.time.LocalTime;

import com.adp.service.Greeting;
import com.adp.service.IFullName;
import com.adp.service.IPower;
import com.adp.service.MaxFinder;

/**
 * 
 * @author sriniva1
 *	Lamda Expression
 *  	Interface interfaceName = (arguments) -> {implementation}
 *  Usage:
 *  		interfaceName.method();
 *  
 */
public class LamdaDemo {

	public static void main(String[] args) {
		MaxFinder maxFinder = (n1, n2) -> (n1>n1)?n1:n2;
		System.out.println(maxFinder.maximum(120,132));
		
		IPower iPower = (a,b)-> {
			long result=1;
			while(b>0) {
				result= result*a;
				b--;
			}
			return result;
		};
		
		System.out.println(iPower.power(2, 5));
		
		
		IFullName iFullName = (firstName, lastName) -> {
			System.out.println(firstName+" "+ lastName);
		};
		
		iFullName.showFullName("Ravi", "Kumar");
		
		
		Greeting greeting = () -> {
			int hour = LocalTime.now().getHour();
			if(hour<=12) {
				System.out.println("Good Morning!");
			}else if(hour<=18) {
				System.out.println("Good Afternoon");
			}else if(hour<=22) {
				System.out.println("Good Evening");
			}else {
				System.out.println("Good Night");
			}
		};
		
		
		greeting.greet();
	}

}
