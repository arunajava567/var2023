package com.adp.service;

@FunctionalInterface
public interface IFullName {
	public abstract void showFullName(String firstName, String lastName);
}
