package com.adp.service;

@FunctionalInterface
public interface MaxFinder {
	public abstract int maximum(int num1, int num2);
}
