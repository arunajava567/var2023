package com.ado.app;

import com.adp.service.Addition;

/**
 * 
 * @author sriniva1
 * In method overloading, implicit casting is done but not explicit casting
 */
public class MethodOverloadTest {

	public static void main(String[] args) {
		Addition addition= new Addition();
		
		System.out.println(addition.add(1, 2)); //exact match
//		System.out.println(addition.add(1, 2.0)); compilation error, double->float is explicit
		System.out.println(addition.add(1,  2.0f)); //exact match
		
		System.out.println(addition.add(1, 'A')); //implicit type cast, char->int

	}

}
