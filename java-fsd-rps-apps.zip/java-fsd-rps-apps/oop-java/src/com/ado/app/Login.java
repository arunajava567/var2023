package com.ado.app;

import java.time.LocalDate;

import com.adp.service.Employee;
import com.adp.service.SwipeCard;

public class Login {

	public static void main(String[] args) {
		SwipeCard card= new SwipeCard("23456ORGADPDEPTIT",
				LocalDate.of(2020, 10, 1),
				LocalDate.of(2022, 12, 30));
		
		Employee employee = new Employee(23456,"Smith");
		
		employee.login(card);

	}

}
