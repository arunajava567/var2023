package com.ado.app;

import java.time.LocalDate;

import com.adp.service.Faculty;
import com.adp.service.Student;

public class PersonDemo {

	public static void main(String[] args) {
//		Person person= new Person(123456784321L,"Smith",LocalDate.of(1990, 10,15));
		
//		System.out.println(person);
		
		Student student= new Student(123454329897L,"Smith",
									LocalDate.of(2001, 1, 1),12,"A",25,"A+");
		
		System.out.println(student);
		
		System.out.println("----------------------------------");
		student.getDetails();
		
		/*
		 * Create a class, Faculty that extends Person with additional attributes,
		 * specialization, experience
		 */

		System.out.println("Faculty details...");
		Faculty faculty = new Faculty(786598794564L,"Jones",LocalDate.of(1975,7,18),
				"Java", 20);
		
		System.out.println(faculty);
	}

}
