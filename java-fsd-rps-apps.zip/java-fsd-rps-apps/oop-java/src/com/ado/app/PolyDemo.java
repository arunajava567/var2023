package com.ado.app;

import java.time.LocalDate;

import com.adp.service.Faculty;
import com.adp.service.Person;
import com.adp.service.Student;

/**
 * 
 * @author sriniva1
 * Instance of sub class can be assigned to super class reference
 *
 */
public class PolyDemo {

	public static void main(String[] args) {
//		Person person = new Student(123454329897L,"Smith",
//									LocalDate.of(2001, 1, 1),12,"A",25,"A+");
//		
		
		//getDetails() method of Student class is executed
		/**
		 * This is called as runtime polymorphism.
		 * 
		 * When instance of sub class is pointed by super class reference and if we
		 * call a method through super class reference, JVM will decide method of 
		 * which class to call only at runtime. That is why this is called as runtime 
		 * polymorphism.
		 * 
		 */
//		person.getDetails(); 
		
		
		Person person=  new Faculty(786598794564L,"Jones",LocalDate.of(1975,7,18),
				"Java", 20);
		
		//getDetails() method of Faculty class is invoked
		person.getDetails();
		
		/*
		 * We cannot invoke the specialized methods i.e. methods
		 * specific to sub class  through super class reference.
		 */
//		person.methodOfFaculty();
		
		
		//Array of references of type, Person
		Person persons[] = new Person[4];
		persons[0]= new Student(123454329897L,"Smith",
				LocalDate.of(2001, 1, 1),12,"A",25,"A+");
		persons[1]= new Faculty(786598794564L,"Jones",LocalDate.of(1975,7,18),
				"Java", 20);
		persons[2]=  new Faculty(886598794500L,"John",LocalDate.of(1985,7,15),
				"Spring", 15);
		persons[3]= new Student(623454329050L,"Ravi",
				LocalDate.of(2000, 10, 10),10,"B",20,"A");
		
		
		showPersonDetails(persons);
		
	}

	private static void showPersonDetails(Person[] persons) {
		//instanceof operator
		for(Person p: persons) {
			if(p instanceof Student) {
				System.out.println("Student details...\n"+p);
				p.dayToDayActivity();
			}else if(p instanceof Faculty) {
				System.out.println("Faculty details...\n"+p);
				p.dayToDayActivity();
			}else {
				System.out.println("Person is abstract class");
			}
		}
		
	}

}
