package com.ado.app;

import java.time.LocalDate;

import com.adp.service.Person;
import com.adp.service.Student;

public class TypecastDemo {

	public static void main(String[] args) {
		/*
		 * instance of subclass pointed by its superclass type
		 * is called implicit casting which is valid.
		 */
		
//		Person person=  new Student(123454329897L,"Smith",
//				LocalDate.of(2001, 1, 1),12,"A",25,"A+");
//		
//		System.out.println(person.getAdharCard());
//
//		Student student= 
//				(Student) new Person(123456784321L,"Smith",LocalDate.of(1990, 10,15));
//		
//		// throws java.lang.ClassCastException
//		student.dayToDayActivity();
//		
		
		
		Object object= new String("Hello");
		System.out.println(object); //Hello
		
		// java.lang.ClassCastException is thrown at runtime
		String string = (String) new Object();
		
	}

}
