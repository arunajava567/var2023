package com.ado.app;

import com.adp.service.Car;
import com.adp.service.Engine;
import com.adp.service.Tyre;

public class CarDemo {

	public static void main(String[] args) {
		Engine engine= new Engine(5675468907L,"Petrol",2600.0);
		
		Tyre[] tyres= new Tyre[4];
		tyres[0]= new Tyre(22,55); tyres[1]= new Tyre(22,55);
		tyres[2]= new Tyre(22,55); tyres[3]= new Tyre(22,55);
		
		//inject the dependencies into Car object(dependent)
		//through constructor
		
		Car myCar= new Car("Swift DeZire",engine,tyres);
		
		System.out.println(myCar);
		
		//Aggregation
		
		//take out engine and left rear tyre
		Engine oldEngine= myCar.getEngine();
		Tyre oldTyre= myCar.getTyres()[2];
		
		System.out.println("Took out the following before destroying my car...");
		System.out.println(oldEngine+","+ oldTyre);
		
		//destroy car, destroying container class object
		myCar=null;
		System.out.println(myCar);
		
	}

}
