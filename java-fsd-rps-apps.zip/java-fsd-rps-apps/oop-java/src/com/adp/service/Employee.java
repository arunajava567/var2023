package com.adp.service;

import java.time.LocalDateTime;

/**
 * 
 * @author sriniva1
 * Dependency: uses-a relationship.
 * 
 * Here the methods of one class use methods of other class to complete the task.
 * There is weak association/bonding between the classes.
 *
 */
public class Employee {
	private Integer empid;
	private String ename;
	
	public Employee() {
		
	}
	
	public Employee(Integer empid, String ename) {
		this.empid=empid;
		this.ename=ename;
	}

	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + "]";
	}
	
	public void login(SwipeCard card) {
		if(card.swipe(this)==true) {
			System.out.println("Welcome, "+ this.ename+", "+LocalDateTime.now());
		}else {
			System.out.println("Sorry! Please contact HR");
		}
	}
	
	
}
