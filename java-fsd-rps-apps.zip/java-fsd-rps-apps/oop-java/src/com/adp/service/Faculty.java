package com.adp.service;

import java.time.LocalDate;

public class Faculty extends Person{
	private String specialization;
	private Integer experience;
	
	public Faculty() {
		
	}

	public Faculty(Long adharCard, String name, LocalDate birthdate, String specialization, Integer experience) {
		super(adharCard, name, birthdate);
		this.specialization = specialization;
		this.experience = experience;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	@Override
	public String toString() {
		return  super.toString()+"\n"+"specialization=" + specialization + ", experience=" + experience;
	}

	@Override
	public void getDetails() {
		System.out.println("I am a faculty");
	}
	
	public void methodOfFaculty() {
		System.out.println("Im specialized method of Faculty");
	}

	@Override
	public void dayToDayActivity() {
		System.out.println("Does reaserch work, takes classes");
		
	}
	
	
	
	
	
}
