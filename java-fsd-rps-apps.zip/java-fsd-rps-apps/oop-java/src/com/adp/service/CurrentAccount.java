package com.adp.service;

public class CurrentAccount extends Account implements Transaction{
	private Double balance;
	public static final Double rateOfInterest;
	
	static {
		rateOfInterest=4.6;
	}
	
	public CurrentAccount() {
		
	}

	public CurrentAccount(Long accountNumber, String accountType, Customer accountHolder, Double balance) {
		super(accountNumber, accountType, accountHolder);
		this.balance = balance;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public static Double getRateofinterest() {
		return rateOfInterest;
	}

	/*
	 * Minimum balance of Rs.10000/- to be maintained
	 */
	@Override
	public Double withdraw(Double amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double deposit(Double amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toString() {
		return super.toString()+ "CurrentAccount [balance=" + balance + "]";
	}
	
	
	
}
