package com.adp.service;

import java.time.LocalDate;

public class SwipeCard {
	private String cardId;
	private LocalDate issueDate;
	private LocalDate expiryDate;
	
	
	public SwipeCard() {
		super();
	}


	public SwipeCard(String cardId, LocalDate issueDate, LocalDate expiryDate) {
		super();
		this.cardId = cardId;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
	}


	public String getCardId() {
		return cardId;
	}


	public void setCardId(String cardId) {
		this.cardId = cardId;
	}


	public LocalDate getIssueDate() {
		return issueDate;
	}


	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}


	public LocalDate getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public boolean swipe(Employee employee) {
		if(cardId.contains(employee.getEmpid().toString())) {
			if(LocalDate.now().isAfter(issueDate) && LocalDate.now().isBefore(expiryDate)) {
				return true;
			}else {
				return false;
			}
			
		}else {
			return false;
		}
	}
	
	
}
