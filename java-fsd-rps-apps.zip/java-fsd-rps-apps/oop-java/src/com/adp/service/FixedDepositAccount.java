package com.adp.service;

public class FixedDepositAccount extends Account{
	private final Double fixedDepositAmount;
	private final Integer fixedDepositDuration;
	public static final Double rateOfInterest;
	
	
	static {
		rateOfInterest=7.5;
	}
	
	public FixedDepositAccount() {
		this.fixedDepositAmount=0.0;
		this.fixedDepositDuration=0;
	}

	
	
	
	public FixedDepositAccount(Long accountNumber, String accountType, Customer accountHolder,
			Double fixedDepositAmount, Integer fixedDepositDuration) {
		super(accountNumber, accountType, accountHolder);
		this.fixedDepositAmount = fixedDepositAmount;
		this.fixedDepositDuration = fixedDepositDuration;
	}




	public Double getFixedDepositAmount() {
		return fixedDepositAmount;
	}

	public static Double getRateofinterest() {
		return rateOfInterest;
	}

	public Integer getFixedDepositDuration() {
		return fixedDepositDuration;
	}




	@Override
	public String toString() {
		return super.toString()+"FixedDepositAccount [fixedDepositAmount=" + fixedDepositAmount + ", fixedDepositDuration="
				+ fixedDepositDuration + "]";
	}

	
	
	
	

	
	
	
	
}
