package com.adp.servicenew;

import com.adp.service.A;

/**
 * 
 * @author sriniva1
 * If instance variable of sub class has same name as instance variable of
 * its super class, it is called data hiding.
 * 
 * When instance of sub class is created, memory is allocated for both
 * instance variables.
 * 
 * An instance method of super class is re-defined in its sub class, it is
 * called as method overriding.
 */
public class B extends A{
	private int data=10; //data hiding

	//method overriding
	@Override
	public void showData() {
		//invokes showData() of class A
		super.showData();
		System.out.println(this.data);
		
	}
	
//	public void showData() {
//		System.out.println(this.data); //same as this.data, refering to "data" of same class
//		System.out.println(this.getData()); 
////		System.out.println(super.data);
//		
//	}
	
	//Method hiding
	/*
	 * If a static/class method of super class and static method of sub-class
	 * have same name, it is called as method hiding.
	 * invoke: B.greetings()
	 */
	public static void greetings() {
		System.out.println("Hello! Welcome to ADP from class B");
	}
	
	
}
