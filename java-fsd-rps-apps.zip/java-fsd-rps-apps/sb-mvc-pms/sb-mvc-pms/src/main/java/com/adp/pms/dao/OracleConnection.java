package com.adp.pms.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;


@Configuration
@PropertySource(value="classpath:jdbc.properties", ignoreResourceNotFound = true)
public class OracleConnection {
	
	@Value("${jdbc.driverClassName}")
	private static String driverClass;
	@Value("${jdbc.url}")
	private static String url;
	@Value("${jdbc.username}")
	private static String username;
	@Value("${jdbc.password}")
	private static String password;
	
	static {
		try {
			//            properties= new Properties();
			//            Reader reader=
			//                    new FileReader("C:\\Users\\sriniva1\\Documents\\adpws\\sb-mvc-pms\\sb-mvc-pms\\src\\main\\resources\\jdbc.properties");
			//            properties.load(reader);
			//
			//            Class.forName(properties.getProperty("db.driver.name"));
			System.out.println(driverClass+","+url+","+username+","+password);
			Class.forName(driverClass);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	
	public static Connection getConnection() throws SQLException {
//		return DriverManager.getConnection(properties.getProperty("db.conn.url"),properties.getProperty("db.username"), properties.getProperty("db.password"));
		return DriverManager.getConnection(url, username, password);
		
	
	}

	public static void testConnection(){
		try {
			Connection connection = getConnection();
			/*
			 * JDBC provides support 5 transaction isolation levels through Connection interface.

				TRANSACTION_NONE: It is represented by integer value 0 does not support transactions.
				TRANSACTION_READ_COMMITTED: It is represented by integer value 2 supports transactions allowing Non-Repeatable Reads and, Phantom Reads.
				TRANSACTION_READ_UNCOMMITTED: It is represented by integer value 1 supports transactions allowing Dirty Reads, Non-Repeatable Reads and, Phantom Reads.
				TRANSACTION_REPEATABLE_READ: It is represented by integer value 4 supports transactions allowing only Phantom Reads.
				TRANSACTION_SERIALIZABLE: It is represented by integer value 8 supports transactions without allowing Dirty Reads, Non-Repeatable Reads and, Phantom Reads.
			 */
			System.out.println(connection.getSchema());
			System.out.println(connection.getTransactionIsolation());
		}catch(SQLException e){
			e.printStackTrace();
		}

	}
}
