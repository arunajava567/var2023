package com.adp.pms.service;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.pms.dao.PersonDAO;
import com.adp.pms.dao.PersonDaoImpl;
import com.adp.pms.dto.Person;
import com.adp.pms.exception.PersonException;

@Service
public class PersonServiceImpl implements PersonService{
	private Logger logger = LoggerFactory.getLogger(PersonServiceImpl.class);
	
	@Autowired
	private PersonDAO personDAO;

	@Override
	public List<Person> getAllPersons() throws PersonException {
		try {
			return personDAO.getAllPersons();
		}catch(SQLException e) {
			logger.error("Converting SQLException to PersonException");
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person getPersonById(Long adharCard) throws PersonException {
		try {
			return personDAO.getPersonById(adharCard);
		}catch(SQLException e) {
			logger.error("Converting SQLException to PersonException");
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person addPerson(Person person) throws PersonException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person updateMobile(Long adharCard, Long mobile) throws PersonException {
		try {
			return personDAO.updateMobile(adharCard, mobile);
		}catch(SQLException e) {
			logger.error("Converting SQLException to PersonException");
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Long deletePerson(Long adharCard) throws PersonException {
		// TODO Auto-generated method stub
		return null;
	}

}
