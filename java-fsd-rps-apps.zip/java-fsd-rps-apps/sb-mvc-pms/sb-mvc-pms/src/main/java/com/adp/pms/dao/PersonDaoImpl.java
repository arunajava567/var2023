package com.adp.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.adp.pms.dto.Person;
import com.adp.pms.mapper.QueryMapper;


@Repository
public class PersonDaoImpl implements PersonDAO {
	Logger logger = LoggerFactory.getLogger(PersonDaoImpl.class);

	@Override
	public List<Person> getAllPersons() throws SQLException {

		try(
				Connection connection= OracleConnection.getConnection();
				Statement statement= connection.createStatement();
				){
			List<Person> personList= new ArrayList<>();
			ResultSet resultSet= statement.executeQuery(QueryMapper.GET_ALL_PERSONS);
			while(resultSet.next()) {
				Person person = new Person();
				person.setAdharCard(resultSet.getLong("adhar_card"));
				person.setName(resultSet.getString("name"));
				person.setBirthdate(resultSet.getDate("birthdate").toLocalDate());
				person.setAddress(resultSet.getString("address"));
				person.setMobile(resultSet.getLong("mobile"));
				person.setEmail(resultSet.getString("email"));
				personList.add(person);
			}
			logger.info("Retrieving "+ personList.size()+" record");	
			return personList;

		}catch(SQLException e) {
			logger.error(e.getMessage());
			throw e;
		}

	}

	@Override
	public Person getPersonById(Long adharCard) throws SQLException {
		try(
				Connection connection= OracleConnection.getConnection();
				PreparedStatement preparedStatement= 
						connection.prepareStatement(QueryMapper.GET_PERSON_BY_ID);
				){

			preparedStatement.setLong(1,adharCard );
			ResultSet resultSet= preparedStatement.executeQuery();
			if(resultSet.next()) {
				Person person = new Person();
				person.setAdharCard(resultSet.getLong("adhar_card"));
				person.setName(resultSet.getString("name"));
				person.setBirthdate(resultSet.getDate("birthdate").toLocalDate());
				person.setAddress(resultSet.getString("address"));
				person.setMobile(resultSet.getLong("mobile"));
				person.setEmail(resultSet.getString("email"));
				logger.info("Retrieving details of person with adharCard: "+ person.getAdharCard());
				return person;
			}else {
				logger.warn("Invalid AdharCard");
				throw new SQLException("Invalid AdharCard");
			}


		}catch(SQLException e) {
//			logger.error(e);
			throw e;
		}
	}

	@Override
	public Person addPerson(Person person) throws SQLException {
//		 TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person updateMobile(Long adharCard, Long mobile) throws SQLException {
		try(
				Connection connection= OracleConnection.getConnection();
				PreparedStatement preparedStatement= 
						connection.prepareStatement(QueryMapper.UPDATE_PERSON);
				){

			preparedStatement.setLong(1,mobile );
			preparedStatement.setLong(2, adharCard);

			/*
			 * For all DML statements(insert/update/delete), JDBC method is same
			 * i.e executeUpdate()
			 */
			int n= preparedStatement.executeUpdate();

			if(n>0) {
				Person person= this.getPersonById(adharCard);
				return person;
			}else {
				logger.warn("Invalid AdharCard");
				throw new SQLException("Invalid AdharCard");
			}
		}catch(SQLException e) {
			logger.error(e.getMessage());
			throw e;
		}
	}

	@Override
	public Long deletePerson(Long adharCard) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
