package com.adp.pms.service;

import java.sql.SQLException;
import java.util.List;

import com.adp.pms.dto.Person;
import com.adp.pms.exception.PersonException;

public interface PersonService {
	public abstract List<Person> getAllPersons() throws PersonException;
	
	public abstract Person getPersonById(Long adharCard) throws PersonException;
	public abstract Person addPerson(Person person) throws PersonException;
	public abstract Person updateMobile(Long adharCard, Long mobile) throws PersonException;
	public abstract Long deletePerson(Long adharCard) throws PersonException;
}
