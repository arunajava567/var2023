package com.adp.spring.service;

import com.adp.spring.bean.Customer;

public class CustomerServiceImpl implements CustomerService {
	@Override
	public void addCustomer(Customer customer) {
		System.out.println(customer.getCustomerName()+ " added to database");
	}
}
