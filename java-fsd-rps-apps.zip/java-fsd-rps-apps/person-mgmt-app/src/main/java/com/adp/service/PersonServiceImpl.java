package com.adp.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.adp.dao.PersonDAO;
import com.adp.dao.PersonDaoImpl;
import com.adp.dto.Person;
import com.adp.exception.PersonException;

public class PersonServiceImpl implements PersonService{
	Logger logger = Logger.getLogger(PersonServiceImpl.class);
	
	PersonDAO personDAO = new PersonDaoImpl();

	@Override
	public List<Person> getAllPersons() throws PersonException {
		try {
			return personDAO.getAllPersons();
		}catch(SQLException e) {
			logger.error("Converting SQLException to PersonException");
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person getPersonById(Long adharCard) throws PersonException {
		try {
			return personDAO.getPersonById(adharCard);
		}catch(SQLException e) {
			logger.error("Converting SQLException to PersonException");
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person addPerson(Person person) throws PersonException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person updateMobile(Long adharCard, Long mobile) throws PersonException {
		try {
			return personDAO.updateMobile(adharCard, mobile);
		}catch(SQLException e) {
			logger.error("Converting SQLException to PersonException");
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Long deletePerson(Long adharCard) throws PersonException {
		// TODO Auto-generated method stub
		return null;
	}

}
