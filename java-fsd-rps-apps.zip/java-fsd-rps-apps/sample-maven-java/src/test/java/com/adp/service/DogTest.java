package com.adp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class DogTest {  

	@BeforeAll  
	public static void init() {  
		System.out.println("Doing stuff");  
	}  
	
	@AfterAll  
	public static void finish() {  
	    System.out.println("Finishing stuff");  
	}
	
	@BeforeEach  
	public void doEach() {  
		System.out.println("Hey Doggo");  
	}  
	
	@AfterEach  
	public void doAfterEach() {  
	    System.out.println("Bye Doggo");  
	}  
	  

	@Test  
	public void testBarkSuccess() {  
		String expectedString = "woof";  
		assertEquals(expectedString, "woof");  
	}  

	@Test  
	public void testBarkFailure() {  
		String expectedString = "Meow";  
		assertEquals(expectedString, "Woof");  
	}
	
	@Disabled("Dog 1 please don't woof")  
	@Test  
	public void testBark1() {  
	    String expectedString = "woof1";  
	    assertEquals(expectedString, "woof1");  
	    System.out.println("WOOF => 1");  
	}  
	
	@Test  
	public void testNotBark() {  
	    String unexpectedString = "";  
	    assertNotEquals(unexpectedString, "woof");  
	    System.out.println("Didn't woof!!");  
	}
	
	@Test  
	public void nullCheck() {  
	    Object dog = null;  
		assertNull(dog);  
	    System.out.println("Null dog :(");  
	}
	
	@Test  
	public void nonNullCheck() {  
	    String dog = "Max";  
	    assertNotNull(dog);  
	    System.out.println("Hey I am " + dog);  
	}
	
	@Test  
	public void trueCheck() {  
	    int dogAge = 2;  
	    assertTrue(dogAge < 5);  
	    System.out.println("I am young :)");  
	}
	
	@Test  
	public void falseCheck() {  
	    int dogAge = 7;  
	    assertFalse(dogAge < 5);  
	    System.out.println("I am old :(");  
	}

	
}