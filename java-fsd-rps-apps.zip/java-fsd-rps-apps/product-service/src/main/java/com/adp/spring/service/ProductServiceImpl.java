package com.adp.spring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adp.spring.dto.ProductDTO;
import com.adp.spring.entity.ProductEntity;
import com.adp.spring.exception.ProductException;
import com.adp.spring.repository.ProductRepository;

import jakarta.persistence.PersistenceException;




@Service(value = "productService")
@Transactional
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public void saveProduct(ProductDTO productDTO) throws ProductException {
		try {
		
			ProductEntity productEntity = modelMapper.map(productDTO, ProductEntity.class);
			productRepository.save(productEntity);
		}catch(PersistenceException e) {
			throw new ProductException(e.getMessage(),e);
		}
		
	}

	@Override
	public List<ProductDTO> getAllProducts() throws ProductException {
		try {
			List<ProductEntity> productEntityList = productRepository.findAll();
			
			
			if (productEntityList.isEmpty()) {
				throw new ProductException("PRODUCTS_UNAVAILABLE");
			}
			
			List<ProductDTO> productDTOList = new ArrayList<>();
			
			productEntityList.forEach(product  -> {
				ProductDTO productDTO = modelMapper.map(product, ProductDTO.class);
				productDTOList.add(productDTO);
			});
			
			return productDTOList;
		}catch(PersistenceException e) {
			throw new ProductException(e.getMessage(),e);
		}
	}

	@Override
	public ProductDTO getProductById(Integer id) throws ProductException {
		try {
			Optional<ProductEntity> productEntity = productRepository.findById(id);
			
			
			if (productEntity.isEmpty()) {
				throw new ProductException("PRODUCT_UNAVAILABLE");
			}
			
			ProductDTO productDTO = modelMapper.map(productEntity, ProductDTO.class);
			return productDTO;
			
			
		}catch(PersistenceException e) {
			throw new ProductException(e.getMessage(),e);
		}
	}

	@Override
	public List<ProductDTO> getProductsByBrand(String brand) throws ProductException {
		try {
			Optional<List<ProductEntity>> productEntityList = productRepository.findByBrand(brand.toLowerCase());
			
			
			if (productEntityList.isEmpty()) {
				throw new ProductException("PRODUCTS_BY_GIVEN_BRAND_UNAVAILABLE");
			}
			
			List<ProductDTO> productDTOList = new ArrayList<>();
			
			productEntityList.get().forEach(product  -> {
				ProductDTO productDTO = modelMapper.map(product, ProductDTO.class);
				productDTOList.add(productDTO);
			});
			
			return productDTOList;
		}catch(PersistenceException e) {
			throw new ProductException(e.getMessage(),e);
		}
	}

	

	
	
	
	
}
