package com.adp.spring.service;

import java.util.List;


import com.adp.spring.dto.ProductDTO;

import com.adp.spring.exception.ProductException;



public interface ProductService {
	public void saveProduct(ProductDTO productDTO) throws ProductException;
	public List<ProductDTO> getAllProducts() throws ProductException;
	public List<ProductDTO> getProductsByBrand(String brand) throws ProductException;
	public ProductDTO getProductById(Integer id) throws ProductException;
	
	
}