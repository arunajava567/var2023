package com.adp.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.adp.spring.dto.ProductDTO;
import com.adp.spring.exception.ProductException;
import com.adp.spring.service.ProductService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;





@Tag(name = "Product", description = "Product Management APIs")
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	//port:8085 is gateway port
	//http://localhost:8085/api/v1/products
	@Operation(summary = "Retrieve all Products", tags = { "products", "get", "filter" })
	  @ApiResponses({
	      @ApiResponse(responseCode = "200", content = {
	          @Content(schema = @Schema(implementation = ProductDTO.class), mediaType = "application/json") }),
	      @ApiResponse(responseCode = "204", description = "There are no products", content = {
	          @Content(schema = @Schema()) }),
	      @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })		
	@GetMapping("/products")
//	@PreAuthorize("hasRole('ADMIN')")
//	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public ResponseEntity<List<ProductDTO>> getAllProducts(){
		try {
			List<ProductDTO> productDTOList = productService.getAllProducts();
			return new ResponseEntity<>(productDTOList, HttpStatus.OK);
		} catch (ProductException e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}
	
	@Operation(
		      summary = "Retrieve a Products by Brand",
		      description = "Get a Product object by specifying its id. The response is Product object with id, brand,name, quantity and price",
		      tags = { "products", "get" })
		  @ApiResponses({
		      @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ProductDTO.class), mediaType = "application/json") }),
		      @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
		      @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) }) 
	@GetMapping("/products/brand/{brand}")
	public ResponseEntity<List<ProductDTO>> getProducstByBrand(@PathVariable String brand){
		try {
			List<ProductDTO> productDTOList = productService.getProductsByBrand(brand);
			return new ResponseEntity<>(productDTOList, HttpStatus.OK);
		}catch(ProductException e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}
	
	
	@Operation(
		      summary = "Retrieve a Product by Id",
		      description = "Get a Product object by specifying its id. The response is Product object with id, brand,name, quantity and price",
		      tags = { "products", "get" })
		  @ApiResponses({
		      @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ProductDTO.class), mediaType = "application/json") }),
		      @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
		      @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
//	@PreAuthorize("hasRole('USER')")
//	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("/products/{id}")
	public ResponseEntity<ProductDTO> getProductById(@PathVariable Integer id) {
		try {
			ProductDTO productDTO = productService.getProductById(id);
			return new ResponseEntity<>(productDTO, HttpStatus.OK);
		} catch (ProductException e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}
	}
	
	
	@Operation(
		      summary = "Authentication and Returning JWT token",
		      description = "Get a JWT token by providing valid credentials. The response is JWT token",
		      tags = { "products", "get" })
		  @ApiResponses({
		      @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ProductDTO.class), mediaType = "application/json") }),
		      @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
		      @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
//	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@PostMapping("/products")
    public ResponseEntity<String> authenticateAndGetToken(@RequestBody ProductDTO productDTO) {
		try {
			 productService.saveProduct(productDTO);
			return new ResponseEntity<>("Product Added", HttpStatus.OK);
		} catch (ProductException e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
		}

    }
	
}
