package com.adp.spring.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.adp.spring.entity.ProductEntity;



public interface ProductRepository extends JpaRepository<ProductEntity, Integer>{
	Optional<ProductEntity> findById(Integer id);
	
	@Query("select p from ProductEntity p where lower(p.brand) = :brand")
	Optional<List<ProductEntity>> findByBrand(@Param("brand") String brand);	
	
	
}
