			JUnit5 Architecture
			
JUnit5 Architecture consists of 3 modules.
	1. JUnit Platform
	2. JUnit Jupiter
	3. Junit Vintage
	
JUnit Platform:
		This contains software to launch testing framework on JVM and also
		contains Testing Engine to run the JUnit test cases.

JUnit Jupiter:
		This API containing new set of annotations and assertion methods
		introduced in JUnit5.
			@BeforeAll, @AfterAll, @BeforeEach, @AfterEach, @Test etc.
		
		
JUnit Vintage:
		This Engine is for downward compatibility to run JUnit3.x and JUnit4.x 
		test cases in JUnit5 platform.
		

	