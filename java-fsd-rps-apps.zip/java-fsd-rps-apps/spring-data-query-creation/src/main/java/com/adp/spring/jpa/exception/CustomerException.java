package com.adp.spring.jpa.exception;

public class CustomerException extends Exception{
	
	public CustomerException() {
		
	}
	
	public CustomerException(String message) {
		super(message);
	}
	
	public CustomerException(String message, Throwable t) {
		super(message,t);
	}

}
