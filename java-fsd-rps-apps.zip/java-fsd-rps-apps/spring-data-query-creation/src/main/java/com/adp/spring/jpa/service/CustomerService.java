package com.adp.spring.jpa.service;

import java.time.LocalDate;
import java.util.List;

import com.adp.spring.jpa.dto.CustomerDTO;
import com.adp.spring.jpa.exception.CustomerException;



public interface CustomerService {

	public CustomerDTO findByEmailId(String emailId) throws CustomerException;

	public CustomerDTO findByEmailIdAndName(String emailId, String name) throws CustomerException;

	public List<CustomerDTO> findByEmailIdOrName(String emailId, String name) throws CustomerException;

	public List<CustomerDTO> findByBirthdateBetween(LocalDate fromDate, LocalDate toDate) throws CustomerException;

	public List<CustomerDTO> findByBirthdateLessThan(LocalDate birthdate) throws CustomerException;

	public List<CustomerDTO> findByBirthdateGreaterThan(LocalDate birthdate) throws CustomerException;

	public List<CustomerDTO> findByBirthdateAfter(LocalDate birthdate) throws CustomerException;

	public List<CustomerDTO> findByBirthdateBefore(LocalDate birthdate) throws CustomerException;

	public List<CustomerDTO> findByEmailIdNull() throws CustomerException;

	public List<CustomerDTO> findByNameLike(String pattern) throws CustomerException;

	public List<CustomerDTO> findByNameOrderByBirthdate(String name) throws CustomerException;

	public List<CustomerDTO> findByNameOrderByBirthdateDesc(String name) throws CustomerException;



	public String findNameByEmailId(String emailId);
	public void updateCustomerEmailId(String newEmailId, Integer customerId) throws CustomerException;
	public void deleteCustomerByEmailId(String emailId) throws CustomerException;


}
