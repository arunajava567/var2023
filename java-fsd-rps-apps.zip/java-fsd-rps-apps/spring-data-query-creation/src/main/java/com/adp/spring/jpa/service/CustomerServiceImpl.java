package com.adp.spring.jpa.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adp.spring.jpa.dto.CustomerDTO;
import com.adp.spring.jpa.entity.Customer;
import com.adp.spring.jpa.exception.CustomerException;
import com.adp.spring.jpa.repository.CustomerRepository;



@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private ModelMapper modelMapper;

	public CustomerDTO findByEmailId(String emailId) throws CustomerException {
		Optional<Customer> optional = customerRepository.findByEmailId(emailId);
		Customer customer = optional.orElseThrow(() -> new CustomerException("CUSTOMER_UNAVAILABLE"));
			
//		CustomerDTO customerDTO = new CustomerDTO();
//		customerDTO.setCustomerId(customer.getCustomerId());
//		customerDTO.setBirthdate(customer.getBirthdate());
//		customerDTO.setEmailId(customer.getEmailId());
//		customerDTO.setName(customer.getName());
//		return customerDTO;
		
		
		CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
		
		return customerDTO;
	}

	@Override
	public CustomerDTO findByEmailIdAndName(String emailId, String name) throws CustomerException {
		Optional<Customer> optional = customerRepository.findByEmailIdAndName(emailId, name);
		Customer customer = optional.orElseThrow(() -> new CustomerException("CUSTOMER_UNAVAILABLE"));
		
//		CustomerDTO customerDTO = new CustomerDTO();
//		customerDTO.setCustomerId(customer.getCustomerId());
//		customerDTO.setBirthdate(customer.getBirthdate());
//		customerDTO.setEmailId(customer.getEmailId());
//		customerDTO.setName(customer.getName());
		
		CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
		return customerDTO;
	}

	@Override
	public List<CustomerDTO> findByEmailIdOrName(String emailId, String name) throws CustomerException {
		List<Customer> customers = customerRepository.findByEmailIdOrName(emailId, name);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByBirthdateBetween(LocalDate fromDate, LocalDate toDate) throws CustomerException {
		List<Customer> customers = customerRepository.findByBirthdateBetween(fromDate, toDate);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByBirthdateLessThan(LocalDate birthdate) throws CustomerException {
		List<Customer> customers = customerRepository.findByBirthdateLessThan(birthdate);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByBirthdateGreaterThan(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByBirthdateGreaterThan(dateOfBirth);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("Service.CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByBirthdateAfter(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByBirthdateAfter(dateOfBirth);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByBirthdateBefore(LocalDate dateOfBirth) throws CustomerException {
		List<Customer> customers = customerRepository.findByBirthdateBefore(dateOfBirth);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByEmailIdNull() throws CustomerException {
		List<Customer> customers = customerRepository.findByEmailIdNull();
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByNameLike(String pattern) throws CustomerException {
		List<Customer> customers = customerRepository.findByNameLike(pattern);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByNameOrderByBirthdate(String name) throws CustomerException {
		List<Customer> customers = customerRepository.findByNameOrderByBirthdate(name);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}

	@Override
	public List<CustomerDTO> findByNameOrderByBirthdateDesc(String name) throws CustomerException {
		List<Customer> customers = customerRepository.findByNameOrderByBirthdateDesc(name);
		List<CustomerDTO> customerList = new ArrayList<>();
		if (customers.isEmpty())
			throw new CustomerException("CUSTOMER_UNAVAILABLE");
		customers.forEach(customer -> {
//			CustomerDTO customerDTO = new CustomerDTO();
//			customerDTO.setCustomerId(customer.getCustomerId());
//			customerDTO.setBirthdate(customer.getBirthdate());
//			customerDTO.setEmailId(customer.getEmailId());
//			customerDTO.setName(customer.getName());
			
			CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);
			customerList.add(customerDTO);
		});
		return customerList;
	}
	
	
	
	
	@Override
	public String findNameByEmailId(String emailId) {
		return customerRepository.findNameByEmailId(emailId);
	}

	@Override
	public void updateCustomerEmailId(String newEmailId, Integer customerId) throws CustomerException {
		Optional<Customer> optional = customerRepository.findById(customerId);

		optional.orElseThrow(() -> new CustomerException("CUSTOMER_UNAVAILABLE"));
		
		customerRepository.updateCustomerEmailId(newEmailId, customerId);
		

	}

	@Override
	public void deleteCustomerByEmailId(String emailId) throws CustomerException {
		// Optional<CustomerEntity> customer = customerRespository.fi

		Integer count = customerRepository.deleteCustomerByEmailId(emailId);
		if (count == 0)
			throw new CustomerException("CUSTOMER_UNAVAILABLE");

	}
	

}
