package com.adp.pms.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.adp.pms.entity.Person;
import com.adp.pms.exception.PersonException;
import com.adp.pms.service.PersonService;

@RestController
@RequestMapping("/api/v1")
public class PersonController {
	@Autowired
    private PersonService personService;
    
   
//  http://localhost:8082/api/v1/persons
    @GetMapping("/persons")
    public ResponseEntity<List<Person>> getAllPersons(){
        try {
            List<Person> persons = personService.getAllPersons();
            return new ResponseEntity<>(persons,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    
    @GetMapping("/persons/{id}")
    public ResponseEntity<Person> getPersonById(@PathVariable Long id){
        try {
            Person person = personService.getPersonById(id);
            return new ResponseEntity<>(person,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    
    
//    http://localhost:8082/api/v1/persons
    @PostMapping("persons")
    public ResponseEntity<Person> addPerson(@RequestBody Person person)
    {
        try {
            Person p1 = personService.addPerson(person);
            return new ResponseEntity<>(p1,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    
    @PutMapping("/persons")
    public ResponseEntity<Person> updatePerson(@RequestBody Person person){
        try {
            
            Person updated = personService.updatePerson(person);
            return new ResponseEntity<>(updated,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    
    @DeleteMapping("/persons/{id}")
    public ResponseEntity<Long> deletePerson(@PathVariable Long id){
        try {
            Long adhar = personService.deletePerson(id);
            return new ResponseEntity<>(adhar,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    
    @GetMapping("/persons/mob/{mobile}")
    public ResponseEntity<Person> getPersonByMobile(@PathVariable Long mobile){
        try {
            Person person = personService.getPersonByMobile(mobile);
            return new ResponseEntity<>(person,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
    
    @GetMapping("/persons/{address}/{birthdate}")
    public ResponseEntity<List<Person>> getPersonsByAddressAndBirthdate(@PathVariable String address,@PathVariable LocalDate birthdate){
        try {
            List<Person> persons = personService.getPersonByAddressAndBirthdate(address, birthdate);
            return new ResponseEntity<>(persons,HttpStatus.ACCEPTED);
        }catch(PersonException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }
}
