package com.adp.pms.service;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adp.pms.dao.PersonDAO;
import com.adp.pms.dao.PersonDaoImpl;
import com.adp.pms.entity.Person;
import com.adp.pms.exception.PersonException;

import jakarta.persistence.PersistenceException;


@Service(value = "personService")
@Transactional
public class PersonServiceImpl implements PersonService{
//	private Logger logger = LoggerFactory.getLogger(PersonServiceImpl.class);
	
	@Autowired
	private PersonDAO personDAO;

	@Override
	public List<Person> getAllPersons() throws PersonException {
		try {
			return personDAO.getAllPersons();
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person getPersonById(Long adharCard) throws PersonException {
		try {
			return personDAO.getPersonById(adharCard);
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person addPerson(Person person) throws PersonException {
		try {
			return personDAO.addPerson(person);
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person updatePerson(Person person) throws PersonException {
		try {
			return personDAO.updatePerson(person);
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Long deletePerson(Long adharCard) throws PersonException {
		try {
			return personDAO.deletePerson(adharCard);
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public Person getPersonByMobile(Long mobile) throws PersonException {
		try {
			return personDAO.getPersonByMobile(mobile);
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	@Override
	public List<Person> getPersonByAddressAndBirthdate(String address, LocalDate birthdate) throws PersonException {
		try {
			return personDAO.getPersonByAddressAndBirthdate(address, birthdate);
		}catch(PersistenceException e) {
			throw new PersonException(e.getMessage(),e);
		}
	}

	

}
