package com.adp.pms.service;

import java.time.LocalDate;
import java.util.List;

import com.adp.pms.entity.Person;
import com.adp.pms.exception.PersonException;

import jakarta.persistence.PersistenceException;

public interface PersonService {
	public abstract List<Person> getAllPersons() throws PersonException;
	
	public abstract Person getPersonById(Long adharCard) throws PersonException;
	public abstract Person addPerson(Person person) throws PersonException;
	public abstract Person updatePerson(Person person) throws PersonException;
	public abstract Long deletePerson(Long adharCard) throws PersonException;
	public abstract Person getPersonByMobile(Long mobile) throws PersonException;
	public abstract List<Person> getPersonByAddressAndBirthdate(String address, LocalDate birthdate) throws PersonException;
}
