package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.adp.spring.config.SpringConfig;
import com.adp.spring.model.Car;




public class ConfigApp {

	public static void main(String[] args) {
		ApplicationContext context=null;
		try {
			context = new AnnotationConfigApplicationContext(SpringConfig.class);
			Car car= (Car) context.getBean("carBean");
			System.out.println(car);

			//shutdown IoC 
			((AbstractApplicationContext)context).registerShutdownHook();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			((AbstractApplicationContext)context).close();
		}

	}
}
