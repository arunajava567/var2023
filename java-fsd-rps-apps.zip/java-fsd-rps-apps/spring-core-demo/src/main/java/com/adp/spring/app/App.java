package com.adp.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.adp.spring.model.Address;
import com.adp.spring.model.Person;



public class App {

	public static void main(String[] args) {
		ApplicationContext context=null;
		try {
			//IoC container 			
			context= new ClassPathXmlApplicationContext("spring.xml");
			Address myAddress1= (Address) context.getBean("addressBean1");
			System.out.println(myAddress1);

			Address myAddress2= (Address) context.getBean("addressBean4");
			System.out.println(myAddress2);

			Address myAddress3= (Address) context.getBean("addressBean1");
			System.out.println(myAddress3);

//			System.out.println(myAddress1==myAddress3);

			Address myAddress4= (Address) context.getBean("addressBean5");
			System.out.println(myAddress4);

			Address myAddress5= (Address) context.getBean("addressBean3");
			System.out.println(myAddress5);

			Person person1= (Person) context.getBean("personBean");
			System.out.println(person1);

			
			
			 //shutdown IoC 
			((AbstractApplicationContext)context).registerShutdownHook();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			((AbstractApplicationContext)context).close();
		}

	}

}
