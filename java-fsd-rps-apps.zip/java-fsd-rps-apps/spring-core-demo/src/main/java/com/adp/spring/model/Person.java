package com.adp.spring.model;

import java.time.LocalDate;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Person {
	private Long adharCardNumber;
	private String name;
	private LocalDate birthdate;



	//byName
//	@Autowired(required = false)
//	@Qualifier(value = "address1")

	//byName
	@Resource(name = "address1")

	// @Autowired is by default type-driven injection
//	@Autowired
	private Address residentialAddress;

	//byName
//	@Autowired(required = false)
//	@Qualifier(value = "address2")

	//byName
	@Resource(name = "address2")

//	@Autowired
	private Address permanentAddress;

	private Long mobile;


	//custom method that receives date as String and converts to LocalDate
	//conversion method converting String to LocalDate
	/*
		if setCustomDate() is a setter method, its property name will be customDate
	 */
	public void setCustomDate(String bdate) {
		if(!(bdate.isEmpty() && bdate.isBlank())){
			this.birthdate= LocalDate.parse(bdate);
		}
	}

}
