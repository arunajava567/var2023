package com.adp.spring.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.adp.spring.model.Car;
import com.adp.spring.model.Engine;




/*
 * This class is configuration class which is equivalent to xml file
 */
@Configuration
@PropertySource(value = "car.properties", ignoreResourceNotFound = true)
public class SpringConfig {
	@Value("${Car.Manufacturer}")
	private String manufacturer;
	@Value("${Car.Brand}")
	private String brandName;
	
	@Value("${Engine.Type}")
	private String engineType;
	
	@Value("#{T(Long).parseLong('${Engine.Sno}')}")
	private Long engineSerialNumber;
	
	@Value("#{T(Double).parseDouble('${Engine.Capacity}')}")
	private Double engineCapacity;

	@Bean(value = "engineBean")
	public Engine setEngine() {
		return new Engine(engineSerialNumber,engineType,engineCapacity);
	}
	
	
	@Bean(value = "carBean")
	public Car setCar() {
		return new Car(manufacturer, brandName,setEngine());
	}

}
