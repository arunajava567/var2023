package com.adp.spring.model;

import java.time.LocalDate;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee implements InitializingBean,DisposableBean{
	private Integer empno;
	private String ename;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate hiredate;
	private String job;
	private Double sal;
	private Integer deptno;
	
	
	@PostConstruct
	public void postConstruct() {
		System.out.println("In post-construct");
	}
	
	@PreDestroy
	public void preDestroy() {
		System.out.println("In pre-destroy");
	}
	
	
	public void customInitialize() {
		System.out.println("custom initialize method invoked");
	}
	
	
	public void customDestroy() {
		System.out.println("custom destroy method invoked");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("DisposableBean's destroy() method invoked");
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("InitializingBean's afterPropertiesSet() method invoked");
		
	}
	
	
	
	
}
