package com.adp.app;


import static org.junit.jupiter.api.Assertions.assertTrue;


public class AppTest {
    
    
   
    public void testApp(){
        assertTrue( true );
    }
}
