package com.adp.spring.controller;


import java.util.Arrays;

import javax.naming.AuthenticationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.adp.spring.dto.AuthRequest;
import com.adp.spring.dto.UserResponse;
import com.adp.spring.entity.UserInfo;
import com.adp.spring.service.AuthService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000/")  

public class AuthController {
	@Autowired
	private AuthService service;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	private String token=null;

	@PostMapping("/register")
	public String addNewUser(@RequestBody UserInfo userInfo) {
		return service.saveUser(userInfo);
	}

	//    @PostMapping("/signin")
	//    public ResponseEntity signin(@RequestBody AuthenticationRequest data, HttpServletResponse response) {
	//        try {
	//            String username = data.getUsername();
	//            Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, data.getPassword()));
	//            User user = (User) authentication.getPrincipal();
	//            String token = jwtTokenProvider.createToken(user);
	//            final Cookie cookie = new Cookie("auth", token);
	//            cookie.setSecure(!environment.acceptsProfiles(Profiles.of("dev")));
	//            cookie.setHttpOnly(true);
	//            cookie.setMaxAge(Integer.MAX_VALUE);
	//            cookie.setPath("/api");
	//            response.addCookie(cookie);
	//
	//            return ok(buildUserResponseObject(user));
	//        } catch (AuthenticationException e) {
	//            throw new BadCredentialsException("Invalid username/password supplied");
	//        }
	//    }

	/*
	 * https://www.learmoreseekmore.com/2022/10/reactjs-v18-jwtauthentication-using-httponly-cookie.html
	 * A JWT needs to be stored in a safe place inside the user’s browser. If you store it 
	 * inside localStorage, it’s accessible by any script inside your page. This is as bad 
	 * as it sounds; an XSS attack could give an external attacker access to the token.

	To reiterate, whatever you do, don’t store a JWT in local storage (or session storage). 
	If any of the third-party scripts you include in your page is compromised, it can access 
	all your users’ tokens.

	To keep them secure, you should always store JWTs inside an httpOnly cookie. This is a 
	special kind of cookie that’s only sent in HTTP requests to the server. It’s never 
	accessible (both for reading or writing) from JavaScript running in the browser.
	 */
//	@PostMapping("/token")
//	public String getToken(@RequestBody AuthRequest authRequest, HttpServletResponse response) {
//		try {
//			Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
//			if (authenticate.isAuthenticated()) {
//				String token = service.generateToken(authRequest.getUsername());
//				final Cookie cookie = new Cookie("auth", token);
//				cookie.setHttpOnly(true);
//				
//				cookie.setMaxAge(1000*60*30);
//				cookie.setPath("/api");
//				response.addCookie(cookie);
//				return token;
//			}else {
//				throw new AuthenticationException("Invalid username/password supplied");
//			}
//		}catch(AuthenticationException e) {
//			throw new BadCredentialsException("Invalid username/password supplied");
//		}
//	}

	
	@PostMapping("/token")
	public UserResponse getToken(@RequestBody AuthRequest authRequest, HttpServletResponse response) {
		try {
			Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
			if (authenticate.isAuthenticated()) {
//				String token = service.generateToken(authRequest.getUsername());
				token = service.generateToken(authRequest.getUsername());
				final Cookie cookie = new Cookie("auth", token);
				cookie.setHttpOnly(true);
				
				cookie.setMaxAge(1000*60*30);
				
				response.addCookie(cookie);
				return service.getUser(token);
				
			}else {
				throw new AuthenticationException("Invalid username/password supplied");
			}
		}catch(AuthenticationException e) {
			throw new BadCredentialsException("Invalid username/password supplied");
		}
	}
	
	
	@GetMapping("/validate")
	public String validateToken(@RequestParam("token") String token) {
		System.out.println("TOKEN"+ token);
		if(service.validateToken(token) == true) {
			System.out.println("..VALID..");
			return "valid";
		}else {
			System.out.println("..INVALID..");
			return "invalid";
		}

	}
	
	@GetMapping("/user")
	public UserResponse getUser() {

		return service.getUser(token);

	}
	
	@GetMapping("/refresh-token")
	public String getRefreshToken() {

	    return "wCH7PEZy1AbvsASAPyM9qo7Bus3qqy";
	}
	
	
}