package com.adp.service;

public class HelloThread extends Thread{
	
	public HelloThread() {
		
	}
	
	public HelloThread(String message) {
		super(message);
	}

	/*
	 * run() contains task/code that the thread executes
	 */
	@Override
	public void run() {
		System.out.println(Thread.currentThread());
		//simulating a task that takes 1000 ms
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("End of thread, "+ Thread.currentThread().getName());
	}
	
	
}
