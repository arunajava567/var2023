package com.adp.app;

public class LambdaRunnable {

	public static void main(String[] args) {
		
		//create runnable object using lamda and pass on to Thread constructor
		Thread thread = new Thread(
				//overriding run() method
				()->{
					System.out.println(Thread.currentThread());
					System.out.println("Hello World!!");
				}
				
				);
		
		thread.start();

	}

}
