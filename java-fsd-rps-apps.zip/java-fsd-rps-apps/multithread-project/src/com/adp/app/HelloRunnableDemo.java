package com.adp.app;

import com.adp.service.HelloRunnable;

public class HelloRunnableDemo {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread());
		
		//create runnable object
		Runnable helloRunnable= new HelloRunnable();
		/* Attach runnable object to thread object. For this we need
		 * to pass runnable object to Thread class constructor
		 * 
		 */
		
		Thread helloThread = new Thread(helloRunnable);
		helloThread.start();// invokes run() method
		
		System.out.println("End of main thread");

	}

}
