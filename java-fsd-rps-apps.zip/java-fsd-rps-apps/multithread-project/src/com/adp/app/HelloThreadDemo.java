package com.adp.app;

import com.adp.service.HelloThread;

public class HelloThreadDemo {

	/*
	 * main() is run by main thread provided by JVM.
	 * 
	 * This main thread has a capability to generate/spawn other threads
	 * which are called as user threads or worker threads.
	 */
	public static void main(String[] args) {
		
		System.out.println(Thread.currentThread());
		Thread helloThread = new HelloThread("hello-thread-1");
		
		/*
		 * To invoke the run method, main thread has to call start() on the
		 * helloThread object. The start() method will implicitly invoke run() method.
		 */
		// at this point, helloThread is spawned and then enters into run() method
		helloThread.start(); 
		
		//pausing main thread for 10 ms
//		try {
//			Thread.sleep(10);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
		
		/*main thread to wait until hello-thread-1 completes its task ie.
		executes the statements in run() method */
		
		try {
			/*
			 * helloThread saying main thread to join me
			 */
			helloThread.join();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		System.out.println("End of main thread");

	}

}
