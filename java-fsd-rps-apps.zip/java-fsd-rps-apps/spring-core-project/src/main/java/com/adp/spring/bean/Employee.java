package com.adp.spring.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Employee implements InitializingBean, DisposableBean{
	private Integer empid;
	private String ename;
	private String job;
	private Double sal;
	private Integer deptno;
	
	
	@PreDestroy
	public void preDestroy() {
		System.out.println("preDestroy annotated method is executed");
	}
	
	
	@PostConstruct
	public void postConstruct() {
		System.out.println("postConstruct annotated method is executed");
	}
	
	
	public void customInit() {
		System.out.println("This is custom init method");
	}
	
	
	public void customDestroy() {
		System.out.println("This is custom destroy method");
	}


	@Override
	public void destroy() throws Exception {
		System.out.println("destory method of DisposableBean interface is executed");
		
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("afterProperties method of InitializingBean interface is executed");
		
	}
	
	
}
