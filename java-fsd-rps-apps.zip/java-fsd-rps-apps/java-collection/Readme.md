  Set implementations
  
  	- Doesn't allow duplicate objects unlike List implementations
  	
  	- Set interface has no additional methods. So all the Set implementations
  	use only the methods of Collection interface.
 
 Note: HashSet and LinkedHashSet allow one null  while List implementations
 can have more than one null.
  	
  
  HashSet : Doesn't guarantee order of entry
  			Back-end data structure is based on hashing algorithm
  LinkedHashSet: Guarantees order of entry
  			Back-end data structure is based on hashing algorithm and in addition
  			has a linked list to maintain the order of entry
  TreeSet: Objects are placed in TreeSet in an order(alphabetical/ascending)
  			Back-end data structure is based binary tree algorithm
  			
  			
  Hashing algorithm
  
  	Before placing an object in Hash implementations, hash function is applied
  	on the object's hashcode. This hash functions returns a value which is 
  	called a slot or bucket. The object is now placed in this slot.
  	
  	
  	HashSet: Default capacity is 16 and capacity increment is 100%.
  	
  	So hashSet by default is allocated a memory block in the heap that has 16 slots.
  	
  	
  		
  		hashfn =  object's hashcode % hashSet size (16)
  		
  		Note: Any integer value % 16 ->  an integer value in arrange of 0-15.
  		
  		Slot number would be anywhere between 0 to 15.
  		
  		
  		Ex. Set<String> namesSet= new HashSet<>();
  	
  		String name1= new String("Smith")
  		namesSet.add(name1); Say, hfn(name1)->3
  		namesSet.add(new String("Lakshmi")); hfn((new String("Lakshmi")->0
  		namesSet.add(new String("Madhavi")); hfn((new String("Madhavi")->0
  		
  		.......
  		
  		If more than one object has same slot, called as hash collision. Unavoidable.
  		
  		Map<K,V>
  		
  		where Key maps to a Value. Both Key and Value are objects. Map implementations
  		cannot have duplicate objects as keys but values can be duplicate.
  		
  		HashMap, LinkedHashMap & TreeMap
  		
  		Main methods:
  			V put(K,V), V get(K), V remove(K)
  			
  		Note: Each element of Map implementation has Key-Value pair.
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	