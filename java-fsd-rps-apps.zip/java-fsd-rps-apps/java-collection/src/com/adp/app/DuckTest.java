package com.adp.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.adp.service.Duck;

public class DuckTest {

	public static void main(String[] args) {
		List<Duck> duckList= new ArrayList<>();
		
		populateDucks(duckList);
		showDucks(duckList);
		Collections.sort(duckList);
		System.out.println("Sorted list of ducks based on breed..");
		showDucks(duckList);
		
		System.out.println("Sorted list of ducks based on weight..");
		/*
		 * Comparator interface:  int compare(object1, object2)
		 */
		Collections.sort(duckList,  (d1,d2)->d1.getWeight().compareTo(d2.getWeight()));
		showDucks(duckList);

	}

	private static void showDucks(List<Duck> duckList) {
		Iterator<Duck> iterator= duckList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
			System.out.println("---------------------------");
		}
		
	}

	private static void populateDucks(List<Duck> duckList) {
		duckList.add(new Duck("Alabio","White",1.5));
		duckList.add(new Duck("Americn Pelican","Grey",1.8));
		duckList.add(new Duck("Crested","Black",2.5));
		duckList.add(new Duck("Indain Runner duck","White",3.5));
		duckList.add(new Duck("Call duck","Grey",1.7));
		
	}

}
