package com.adp.app;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		//HashMap doesn't guarantee iteration order
//		Map<Long,String> mobileMap = new HashMap<>();
		
		//LinkedHashMap guarantees iteration order
//		Map<Long,String> mobileMap = new LinkedHashMap<>();
		
		Map<Long,String> mobileMap = new TreeMap<>();

		

		mobileMap.put(8767876765L, "Ravi Kumar");
		mobileMap.put(9767876700L, "Lakshmi");
		mobileMap.put(7717879765L, "Manisha");
		mobileMap.put(5767899700L, "Laxman");

		System.out.println(mobileMap.size());

		System.out.println(mobileMap.get(9767876700L));

		mobileMap.remove(9767876700L);

		System.out.println(mobileMap.size());

		System.out.println(mobileMap.get(9767876700L));
		mobileMap.put(8767899699L, "Ram");
		System.out.println("Details...");
		for(Map.Entry<Long,String> m : mobileMap.entrySet()) {
			System.out.println(m.getKey()+":"+ m.getValue());
		}
		
		System.out.println("Keys...");
		Set<Long> mobileSet = mobileMap.keySet();
		mobileSet.stream().forEach(System.out::println);
		
		System.out.println("Values...");
		Collection<String> collection = mobileMap.values();
		collection.stream().forEach(System.out::println);
		

	}

}