package com.adp.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		List<String> namesList= new ArrayList<>();
		
		namesList.add("Ravi Kumar");
		namesList.add(new String("Vinod"));
		namesList.add("Lakshmi");
		namesList.add(0,"Rohit");
		System.out.println(namesList.size());
		
		
		System.out.println(namesList.get(1));
		namesList.set(2, "Vinod Khanna");
		System.out.println(namesList.contains("Lakshmi"));
		
		System.out.println("Names...");
		Iterator<String> iterator = namesList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("Sorted list of names..");
		
		Collections.sort(namesList);
		
		iterator = namesList.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		//converting arraylist to synchronized list
		List<String> namesListSync  = Collections.synchronizedList(namesList);
		
		//Following is valid
		List<Integer> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		
		
		int list[]= {1,2,3,4,5};
		//Type mismatch: cannot convert from List<int[]> to List<Integer>
		// int -> Integer is implicit but not  int[]> to List<Integer>
//		List<Integer> myList = Arrays.asList(list);
		
		/*
		 * solution:
		 *      Declarative, functional programming
		 * 		List<Integer> list = Arrays.stream(list).boxed().toList();
		 */

		List<Integer> myList= new ArrayList<>();
		//imperative
		for(int i: list) {
			myList.add(i);
		}
		
		System.out.println(myList);
	}

}
