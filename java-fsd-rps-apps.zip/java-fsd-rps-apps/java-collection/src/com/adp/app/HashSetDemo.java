package com.adp.app;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class HashSetDemo {

	public static void main(String[] args) {
		//insertion order is not guaranteed
//		Set<String> namesSet = new HashSet<>();
		
		//insertion order is guaranteed
//		Set<String> namesSet = new LinkedHashSet<>();
		
		//sorted list of objects
		Set<String> namesSet = new TreeSet<>();
		
		
		namesSet.add(new String("Smith"));
		namesSet.add(new String("Lakshmi"));
		namesSet.add(new String("Madhavi"));
		namesSet.add(new String("Ravi"));
		namesSet.add(new String("Ravi"));
		System.out.println(namesSet.size());
		
		
		Iterator<String> iterator = namesSet.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		

	}

}
