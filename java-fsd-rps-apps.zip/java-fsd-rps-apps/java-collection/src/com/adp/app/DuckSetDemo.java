package com.adp.app;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.adp.service.Duck;

public class DuckSetDemo {

	public static void main(String[] args) {
		Set<Duck> duckSet = new HashSet<>();
		
		populateDucks(duckSet);
		System.out.println(duckSet.size());
		showDucks(duckSet);

	}

	private static void populateDucks(Set<Duck> duckSet) {
		duckSet.add(new Duck("Alabio","White",1.5));
		duckSet.add(new Duck("Americn Pelican","Grey",1.8));
		duckSet.add(new Duck("Crested","Black",2.5));
		duckSet.add(new Duck("Indain Runner duck","White",3.5));
		duckSet.add(new Duck("Call duck","Grey",1.7));
		duckSet.add(new Duck("Alabio","White",1.5));
		
	}

	private static void showDucks(Set<Duck> duckSet) {
		//Imperative programming
//		Iterator<Duck> iterator = duckSet.iterator();
//		while(iterator.hasNext()) {
//			System.out.println(iterator.next());
//			System.out.println("----------------------");
//		}
		
		//Declarative/ functional programming
		duckSet.stream().forEach(System.out::println);
		
	}

}
