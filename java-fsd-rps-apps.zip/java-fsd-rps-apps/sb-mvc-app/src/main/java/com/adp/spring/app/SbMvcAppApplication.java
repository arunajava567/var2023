package com.adp.spring.app;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/*
 * Console Application
 * Implement CommandLineRunner interface and override run()
 */
@SpringBootApplication(scanBasePackages = "com.adp.spring")
public class SbMvcAppApplication implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(SbMvcAppApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SbMvcAppApplication.class, args);

	}

	/*
	 * String ... args is variable length argument parameter
	 * 
	 * ... is called ellipse operator
	 */
	@Override
	public void run(String... args) throws Exception {
		System.out.println("This is command line runner application");
		logger.info("Hello!");

		System.out.println(args.length);
		
		if(args.length>0) {
			for(String s: args) {
				System.out.println(s);
			}
		}

	}

}
