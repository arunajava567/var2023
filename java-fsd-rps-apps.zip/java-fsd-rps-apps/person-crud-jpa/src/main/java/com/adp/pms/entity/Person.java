package com.adp.pms.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*
 * The name attribute of the @SequenceGenerator is also used to reference the 
 * database sequence object that’s called to get the new entity identifiers
 */
@Entity
@Table(name = "batch2_srini_person_t")
public class Person {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "batch2_srini_person_seq")
	@SequenceGenerator(
		    name = "batch2_srini_person_seq",
		    allocationSize = 1
		)
	private Long adharCard;
	private String name;
	private LocalDate birthdate;
	private String address;
	private Long mobile;
	private String email;
	
	public Person() {
		
	}

	public Person(Long adharCard, String name, LocalDate birthdate, String address, Long mobile, String email) {
		super();
		this.adharCard = adharCard;
		this.name = name;
		this.birthdate = birthdate;
		this.address = address;
		this.mobile = mobile;
		this.email = email;
	}
	
	public Person(String name, LocalDate birthdate, String address, Long mobile, String email) {
		super();
		
		this.name = name;
		this.birthdate = birthdate;
		this.address = address;
		this.mobile = mobile;
		this.email = email;
	}

	public Long getAdharCard() {
		return adharCard;
	}

	public void setAdharCard(Long adharCard) {
		this.adharCard = adharCard;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(LocalDate birthdate) {
		this.birthdate = birthdate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Person [adharCard=" + adharCard + ", name=" + name + ", birthdate=" + birthdate + ", address=" + address
				+ ", mobile=" + mobile + ", email=" + email + "]";
	}
	
	
}
