package com.adp.pms.app;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.adp.pms.entity.Person;

public class App {
	private static EntityManagerFactory emf=
			Persistence.createEntityManagerFactory("person-crud-jpa");
	private static EntityManager entityManager=null;

	public static void main( String[] args ){
		try {
			entityManager= emf.createEntityManager();
			
			//Create operation

			//			entityManager.getTransaction().begin();
			//			Person person= new Person("Clarke",LocalDate.of(1995, 1, 12),"Mumbai",
			//					8898675600L,"clarke@gmail.com");
			//			entityManager.persist(person);
			//			entityManager.flush();
			//			entityManager.getTransaction().commit();
			//			System.out.println("Person Added");

			//Read operation
			
//			Person person = entityManager.find(Person.class, 3L);
//			if(person != null) {
//				System.out.println(person);
//			}else {
//				System.out.println("Invalid AdharCard Number");
//			}
			
			//Read all operation
			
			String jql ="from Person";
			Query query = entityManager.createQuery(jql);
			List<Person> personList = query.getResultList();
			personList.stream().forEach(System.out::println);
			
			
			//Update operation
//			Person person = entityManager.find(Person.class, 2L);
//			if(person != null) {
//				entityManager.getTransaction().begin();
//				person.setAddress("New Delhi");
//				Person updatedPerson = entityManager.merge(person);
//				entityManager.flush();
//				entityManager.getTransaction().commit();
//				System.out.println(updatedPerson);
//			}
			
			//Delete operation
//			Person person = entityManager.find(Person.class, 2L);
//			if(person != null) {
//				entityManager.getTransaction().begin();
//				person.setAddress("New Delhi");
//				entityManager.remove(person);
//				entityManager.flush();
//				entityManager.getTransaction().commit();
//				System.out.println("Person deleted");
//			}

		}catch(PersistenceException e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();

		}finally {
			emf.close();
		}
	}
}
