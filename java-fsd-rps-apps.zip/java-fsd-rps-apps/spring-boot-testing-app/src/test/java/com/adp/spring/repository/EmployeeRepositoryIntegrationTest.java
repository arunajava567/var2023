package com.adp.spring.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.adp.spring.SpringBootTestingAppApplication;
import com.adp.spring.entity.Employee;

//@RunWith(SpringRunner.class)
//@ExtendWith is JUnit5 version for JUnit4 @RunWith
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { SpringBootTestingAppApplication.class })
//to use the same data source as your regular application i.e to run DataJpaTest with Oracle
//without the following annotation and with only @DataJpaTest, configures a in-memory db by default
@AutoConfigureTestDatabase(replace=Replace.NONE)
/*
 * The @DataJpaTest uses @Transactional under the hood. 
 * A test is wrapped inside a transaction that is rolled back at the end. 
 * This means that when using e.g. Hibernate one needs to pay special 
 * attention to how the tested code is written. 
 * As shown below, a manual flush is indeed required:
 */
//@SpringBootTest
@DataJpaTest
public class EmployeeRepositoryIntegrationTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void whenFindByName_thenReturnEmployee() {
        Employee employee = new Employee("alex",LocalDate.of(1999, 10,15));
        entityManager.persistAndFlush(employee);

        Employee found = employeeRepository.findByName(employee.getName());
        assertThat(found.getName()).isEqualTo(employee.getName());
    }

    @Test
    public void whenInvalidName_thenReturnNull() {
        Employee fromDb = employeeRepository.findByName("doesNotExist");
        assertThat(fromDb).isNull();
    }

    @Test
    public void whenFindById_thenReturnEmployee() {
        Employee emp = new Employee("test",LocalDate.of(1990, 10,10));
        entityManager.persistAndFlush(emp);

        Employee fromDb = employeeRepository.findById(emp.getId()).orElse(null);
        assertThat(fromDb.getName()).isEqualTo(emp.getName());
    }

    @Test
    public void whenInvalidId_thenReturnNull() {
        Employee fromDb = employeeRepository.findById(-11l).orElse(null);
        assertThat(fromDb).isNull();
    }

    @Test
    public void givenSetOfEmployees_whenFindAll_thenReturnAllEmployees() {
        Employee alex = new Employee("alex",LocalDate.of(1990, 10,10));
        Employee ron = new Employee("ron",LocalDate.of(1995, 10,10));
        Employee bob = new Employee("bob",LocalDate.of(1991, 10,10));

        List<Employee> allEmployeesBefore = employeeRepository.findAll();
        
        entityManager.persist(alex);
        entityManager.persist(bob);
        entityManager.persist(ron);
        entityManager.flush();

        List<Employee> allEmployeesAfter = employeeRepository.findAll();

        assertThat(allEmployeesAfter)
        .hasSize(allEmployeesBefore.size()+3);

    }
}
