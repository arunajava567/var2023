package com.adp.app;

public class DivideDemo {

	public static void main(String[] args) {
		//		try {
		//			int numerator= Integer.parseInt(args[0]);
		//			int denominator = Integer.parseInt(args[1]);
		//
		//			int result = numerator/denominator;
		//			System.out.println(result);
		//		}catch(NumberFormatException e) {
		//				e.printStackTrace();
		//		}catch(ArrayIndexOutOfBoundsException e) {
		//			System.out.println(e.getMessage());
		//		}catch(ArithmeticException e) {
		//			System.out.println("Cannot divide by zero");
		//		}
		//		
		//		System.out.println("END");



		try {
			int numerator= Integer.parseInt(args[0]);
			int denominator = Integer.parseInt(args[1]);

			int result = numerator/denominator;
			System.out.println(result);
		}catch(NumberFormatException e) {
			e.printStackTrace();
		}catch(Exception e) {
			System.out.println("Cannot divide by zero");
		}

		System.out.println("END");

	}








}
