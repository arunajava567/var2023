package com.adp.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.adp.service.CredentialException;

public class Login {

	public static void main(String[] args) throws IOException {
		try(
				BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
				) {
			System.out.println("Enter userid: ");
			String userid = br.readLine();
			System.out.println("Enter password: ");
			String password = br.readLine();
			
			if( ! (userid.equals("admin")  && password.equals("admin@123") )) {
				throw new CredentialException("Invalid Credentials");
			}
			
			System.out.println("Hi, "+ userid+" welcome");
			
		}catch(CredentialException e) {
			e.printStackTrace();
		}
		
		System.out.println("END");

	}

}
