package com.adp.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CheckedExceptionDemo {

	//	public static void main(String[] args) throws IOException {
	//		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	//		System.out.println("Enter yor name: ");
	//		String name= br.readLine();
	//
	//	}

	//	public static void main(String[] args) {
	//		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	//		
	//		try {
	//			
	//			System.out.println("Enter yor name: ");
	//			String name= br.readLine();
	//			System.out.println("Hi, "+name);
	//		} catch (IOException e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//		} finally {
	//			try {
	//				br.close();
	//			} catch (IOException e) {
	//				// TODO Auto-generated catch block
	//				e.printStackTrace();
	//			}
	//		}
	//
	//	}


	// method handing exceptions using try..catch block


	//	public static void main(String[] args) {
	//		accept();
	//
	//	}

	//	private static void accept() {
	//		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	//
	//		try {
	//
	//			System.out.println("Enter yor name: ");
	//			String name= br.readLine();
	//			System.out.println("Hi, "+name);
	//		} catch (IOException e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//		} finally {
	//			try {
	//				br.close();
	//			} catch (IOException e) {
	//				// TODO Auto-generated catch block
	//				e.printStackTrace();
	//			}
	//		}
	//	}


	// method throwing exception to calling function

	//	public static void main(String[] args) {
	//		try {
	//			accept();
	//		} catch (IOException e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//		}
	//
	//	}
	
	
	

//	public static void main(String[] args) throws IOException{
//
//		accept();
//
//
//	}

	//	private static void accept() throws IOException {
	//		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
	//
	//
	//
	//		System.out.println("Enter yor name: ");
	//		String name= br.readLine();
	//		System.out.println("Hi, "+name);
	//
	//	}

	
	
	
	public static void main(String[] args) throws IOException,Exception{

		accept();

	}

	private static void accept() throws IOException  {
		
		
		try(
				BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
				) {
			System.out.println("Enter yor name: ");
			String name= br.readLine();
			System.out.println("Hi, "+name);
		}catch(IOException e) {
			e.printStackTrace();
			//re-throwing an exception
			throw e;
		}

	}








}
