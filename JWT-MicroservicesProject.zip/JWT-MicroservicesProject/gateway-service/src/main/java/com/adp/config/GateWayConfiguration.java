//package com.adp.config;
//
//import org.springframework.cloud.gateway.route.RouteLocator;
//import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class GateWayConfiguration {
//	
//	@Bean
//	public RouteLocator getLocators(RouteLocatorBuilder builder) {
//		return builder.routes()
//					.route(p -> p.path("/api/v1/auth/**").uri("lb://AUTH-SERVICE"))
//					  .route(p -> p.path("/api/v1/gc/**").uri("lb://CONSUMER-SERVICE"))
//					  .route(p -> p.path("/api/v1/hc/**").uri("lb://PRODUCER-SERVICE"))
//					  .build();
//	}
//}