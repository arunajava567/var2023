package com.adp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/hc")
public class HelloController {
	
//	@Value("${eureka.instance.metadataMap.instanceId}")
//	private String instanceDetails;

	//http://localhost:8081/api/v1/hc/hello
	@GetMapping("/hello")
	public String sayHello() {
//		return "Hello, I am producer service: "+ instanceDetails;
		return "Hello, I am producer service: ";
	}
}
