package com.adp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.adp.feign.HelloFeignService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/api/v1/gc")
public class GreetingController {
	
	@Autowired
	private RestTemplate restTemplate;
	
//	@Value("${eureka.instance.metadataMap.instanceId}")
//	private String instanceDetails;
	
	@Autowired
	private HelloFeignService helloFeign;
	
	//http://localhost:8082/api/v1/gc/greet
	@GetMapping("/greet")
	public String sayGreeting() {
		return "Hi, Welcome";
	}
	
	
	@GetMapping("/hellogreet")
	public String sayHelloGreeting() {
//		String uri="http://localhost:8081/api/v1/hc/hello";
		
		String uri="http://PRODUCER-SERVICE/api/v1/hc/hello";
		String response = restTemplate.getForObject(uri,String.class);
//		return "From Consumer Service: " +instanceDetails+" " +response;
		return "From Consumer Service: "  +response;
	}
	
	@CircuitBreaker(name = "PRODUCER-SERVICE", fallbackMethod = "goToFallback")
	@GetMapping("/feign/hellogreet")
	public String sayHelloAgain() {
		String response = helloFeign.getInfoFromProducerService();
		return response;
	}
	
	public String goToFallback(Exception e) {
		return "The called service is temporarily down at the moment";
	}
}