package com.adp.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("PRODUCER-SERVICE")
public interface HelloFeignService {
	@RequestMapping("/api/v1/hc/hello")
	public String getInfoFromProducerService();
}
