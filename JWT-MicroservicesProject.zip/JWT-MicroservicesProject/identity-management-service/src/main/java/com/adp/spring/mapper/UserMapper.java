package com.adp.spring.mapper;

import com.adp.spring.dto.UserDto;
import com.adp.spring.entity.User;

public interface UserMapper {

    UserDto toUserDto(User user);
}