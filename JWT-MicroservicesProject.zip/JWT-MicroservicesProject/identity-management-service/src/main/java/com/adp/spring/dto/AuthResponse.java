package com.adp.spring.dto;

public record AuthResponse(String accessToken) {
}
