package com.adp.spring.dto;

//immutable data objects
public record UserDto(Long id, String username, String name, String email, String role) {
    
}

// UserDto userDto = new UserDto(1,"Smith","smith@adp.com","ADMIN");

//public class UserDto{
//	private final Long id;
//	private final String username;
//	private final String email;
//	private final String role;

//getters
//no setters
//}