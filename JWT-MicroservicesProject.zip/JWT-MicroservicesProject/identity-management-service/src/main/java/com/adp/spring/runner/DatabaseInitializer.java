package com.adp.spring.runner;




import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.adp.spring.config.WebSecurityConfig;
import com.adp.spring.entity.User;
import com.adp.spring.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class DatabaseInitializer implements CommandLineRunner {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (!userService.getUsers().isEmpty()) {
        	
        	log.info("Database is not empty");
            return;
        }
        USERS.forEach(user -> {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userService.saveUser(user);
        });
        log.info("Database initialized");
    }

    // id,username,password,name,email,role
 
    private static final List<User> USERS = Arrays.asList(
            new User("admin", "admin", "Admin", "admin@adp.com", WebSecurityConfig.ADMIN),
            new User("user", "user", "User", "user@adp.com", WebSecurityConfig.USER)
    );
}
