package com.adp.spring.mapper;




import org.springframework.stereotype.Service;

import com.adp.spring.dto.UserDto;
import com.adp.spring.entity.User;



@Service
public class UserMapperImpl implements UserMapper {

    @Override
    public UserDto toUserDto(User user) {
        if (user == null) {
            return null;
        }
        
        return new UserDto(user.getId(), user.getUsername(), user.getName(), user.getEmail(), user.getRole());
    }

   
}
