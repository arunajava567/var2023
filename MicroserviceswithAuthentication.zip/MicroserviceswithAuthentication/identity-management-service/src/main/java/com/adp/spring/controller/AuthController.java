package com.adp.spring.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.adp.spring.dto.AuthRequest;
import com.adp.spring.entity.UserInfo;
import com.adp.spring.service.AuthService;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {
    @Autowired
    private AuthService service;

    @Autowired
    private AuthenticationManager authenticationManager;
/*
    {
    	"name": "adpb03",
    	"password": "adp03@123",
    	"email":"adp03@adp.com",
    	"roles":"ADMIN"
    }
     {
    	"name": "adp03",
    	"password": "adp04@123",
    	"email":"adp04@adp.com",
    	"roles":"USER"
    }
    		*/
    //http://localhost:9898/auth/register
    @PostMapping("/register")
    public String addNewUser(@RequestBody UserInfo userInfo) {
        return service.saveUser(userInfo);
    }

    /*
     * {
			"username": "java3",
			"password": "java3@123"
		}

eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqYXZhMyIsImlhdCI6MTY5NDY3NDEyMSwiZXhwIjoxNjk0NjkyMTIxfQ.jE16G4CJsNKq1XT3vr36uZtAQIy2vqdSW0zSJDSIxO8

eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0cmFpbmVyIiwiaWF0IjoxNjk0Njc5Mjk5LCJleHAiOjE2OTQ2OTcyOTl9.pgEchw3-N3iAH_PavlFnY3Cxj_88j9hgPQldhxIukso
     */
    //  http://localhost:9898/auth/token  --- post
    @PostMapping("/token")
    public String getToken(@RequestBody AuthRequest authRequest) {
    	String token=null;
        Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
        if (authenticate.isAuthenticated()) {
        	token=service.generateToken(authRequest.getUsername());
        	System.out.println(token);
            return token;
        } else {
            throw new RuntimeException("invalid access");
        }
    }
   
	/*
	 
	 http://localhost:9898/auth/validate?token=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0cmFpbmVyIiwiaWF0IjoxNjk0Njc5Mjk5LCJleHAiOjE2OTQ2OTcyOTl9.pgEchw3-N3iAH_PavlFnY3Cxj_88j9hgPQldhxIukso

	 */
    
    
    
    @GetMapping("/validate") public String validateToken(@RequestParam("token")String token) {
    	System.out.println("TOKEN"+ token);
    		if(service.validateToken(token) == true) {
    			System.out.println("..VALID..");
    		return "valid"; 
    		}else {
    			System.out.println("..INVALID.."); return "invalid";
	  }
	  
	  }
    @GetMapping("/check")
    public String check() {
    	return "just for checking";
    }
}